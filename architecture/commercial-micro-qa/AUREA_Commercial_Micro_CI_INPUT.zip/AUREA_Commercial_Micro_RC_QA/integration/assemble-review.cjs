'use strict';
// Offline overlay build only. No deploy command, no git write, no DB call.
const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process'),{createRequire}=require('node:module');
const {createHash}=require('node:crypto');
const baseline='7e2908e4e8c234a4bb8056f2017f02c70cfdb7c5';
const repo=path.resolve(process.argv[2]||'.');const out=path.resolve(process.argv[3]||'micro-review-output');
const rc=path.resolve(__dirname,'..');const arch=path.join(repo,'architecture');
const run=(...args)=>cp.execFileSync('git',['-C',repo,...args],{encoding:'utf8'}).trim();
if(run('rev-parse','HEAD')!==baseline||run('status','--porcelain'))throw Error('Pinned clean checkout required');
if(fs.existsSync(out)||out===repo||out.startsWith(repo+path.sep))throw Error('Use a fresh output directory outside the source checkout');
const r=require('node:module').createRequire(path.join(repo,'package.json'));const esbuild=r('esbuild');
const edu=r(path.join(arch,'signature22-education.cjs'));
const {createProductionPublicConfig}=r(path.join(arch,'postgrest-runtime/production-public-config.cjs'));
const {renderHeaders}=r(path.join(arch,'activation-candidate/headers.cjs'));
const {LOCK}=edu;
const master=fs.readFileSync(path.join(arch,'assets/signature22-kringle.locked.html'));
if(createHash('sha256').update(master).digest('hex')!==LOCK)throw Error('Locked Signature asset changed');
const doc=edu.educationDocument(master);
const cfg=createProductionPublicConfig({environment:'production'});if(cfg.manager!==false||cfg.employee!==false)throw Error('Activation must remain OFF');
const work=path.join(out,'build-input');const browser=path.join(out,'browser-overlay','puls-app','edukacija');const server=path.join(out,'server-functions');
for(const dir of [work,browser,server,path.join(out,'admin-overlay'),path.join(out,'database')])fs.mkdirSync(dir,{recursive:true});
for(const file of ['education-client.cjs','education-handler.cjs','education-login.cjs','commercial-policy.cjs'])fs.copyFileSync(path.join(rc,'runtime',file),path.join(work,file));
fs.writeFileSync(path.join(work,'locked-document.json'),JSON.stringify(doc));
// This wrapper reuses the existing production policy, including all seven OFF defaults.
fs.copyFileSync(path.join(arch,'activation-candidate/policy.cjs'),path.join(work,'policy.cjs'));
fs.writeFileSync(path.join(work,'aurea-education.mjs'),`import handler from './education-handler.cjs';\nimport document from './locked-document.json';\nimport policyModule from './policy.cjs';\nexport const config={path:'/api/education',method:['POST'],rateLimit:{windowLimit:20,windowSize:60,aggregateBy:['ip','domain']}};\nexport default req=>{const env=process.env,p=policyModule.policy(env);return handler.createEducationHandler({url:policyModule.API,origin:policyModule.ORIGIN,publishableKey:env.AUREA_SUPABASE_PUBLISHABLE_KEY,document,enabled:p.manager||p.employee})(req);};\n`);
(async()=>{
 await esbuild.build({entryPoints:[path.join(work,'education-login.cjs')],bundle:true,platform:'browser',format:'iife',minify:true,nodePaths:[path.join(repo,'node_modules')],outfile:path.join(browser,'education.bundle.js')});
 await esbuild.build({entryPoints:[path.join(work,'aurea-education.mjs')],bundle:true,platform:'node',target:'node22',format:'esm',outfile:path.join(server,'aurea-education.mjs')});
 for(const file of ['education.html','education.css'])fs.copyFileSync(path.join(__dirname,file),path.join(browser,file==='education.html'?'index.html':file));
 fs.writeFileSync(path.join(out,'browser-overlay','puls-app','production-config.js'),'globalThis.AUREA_PRODUCTION_CONFIG=Object.freeze('+JSON.stringify(cfg)+');\n');
 // Preserve existing header rules. Generate narrow replacements for education only; do not deploy unverified CSP.
 const headers=renderHeaders();const blocks=headers.trimEnd().split(/\n\s*\n/);const eduPaths=['/puls-app/edukacija','/puls-app/edukacija/*'];
 let changed=0;const next=blocks.map(b=>{const name=b.split('\n')[0];if(!eduPaths.includes(name))return b;changed++;return name+"\n  Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self' data:; frame-src 'self' about:; connect-src 'self' https://dlibifwlmbfkboerlmqd.supabase.co; form-action 'none'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'\n  Cache-Control: no-store";});
 if(changed!==2)throw Error('Header baseline mismatch');
 fs.writeFileSync(path.join(out,'browser-overlay','_headers.review'),next.join('\n\n')+'\n');
 // Existing archived private portals carry old 39-EUR label and formula. Produce review copies only.
 for(const file of ['billing-admin-production-portal.html','billing-admin-staging-portal.html','admin-staging-portal.html','admin-qa.html']){
  const src=fs.readFileSync(path.join(arch,'commercial',file),'utf8');
  const next=src.replace(/Math\.max\(3900,\s*n\s*\*\s*\(p==='annual'\?250:300\)\)\s*\*\s*\(p==='annual'\?12:1\)/g,"n*(p==='annual'?3000:300)").replace(/Minimum 39 EUR mesečno\./g,'Bez minimalnog iznosa po kompaniji.').replace(/Minimalni mesečni iznos je 39 EUR\./g,'Bez minimalnog iznosa po kompaniji.');
  if(/Math\.max\(\s*3900|minimum[^<\n]{0,30}39\s*(EUR|€)/i.test(next))throw Error('Unresolved price path: '+file);
  fs.writeFileSync(path.join(out,'admin-overlay',file),next);
 }
 // Current protected private admin uses JSON, not the legacy calculator.
 const admin=fs.readFileSync(path.join(arch,'activation-candidate/private-admin.html'),'utf8');
 const anchor='<section id="workspace" hidden>';if(admin.split(anchor).length!==2)throw Error('Admin baseline mismatch');
 fs.writeFileSync(path.join(out,'admin-overlay','private-admin.html'),admin.replace(anchor,anchor+'<p>Tarifa: 3 EUR po licenciranom korisniku mesečno ili 30 EUR po korisniku godišnje unapred (2,50 EUR mesečni ekvivalent). Bez minimalnog iznosa. Poklonjena licenca: 0 EUR. Iznos naloga potvrđuje server; poreski tretman i domaća valuta po odobrenju knjigovođe.</p>'));
 for(const name of fs.readdirSync(path.join(rc,'database')))fs.copyFileSync(path.join(rc,'database',name),path.join(out,'database',name));
 if(run('rev-parse','HEAD')!==baseline||run('status','--porcelain'))throw Error('Source changed during assembly');
 fs.rmSync(work,{recursive:true,force:true});console.log('Overlay compiled; production config OFF. Browser, DB and header verification still required. No deploy.');
})().catch(e=>{console.error(e.message);process.exitCode=1;});
