#!/usr/bin/env bash
# Run on a machine with git, Node 22, npm and Docker; no Supabase credentials or deployment.
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/.." && pwd)
REPO=${1:?Supply local GitHub checkout of pinned source}
BASE=7e2908e4e8c234a4bb8056f2017f02c70cfdb7c5
for c in git node npm docker; do command -v "$c" >/dev/null || { echo "Missing $c" >&2;exit 1; };done
[[ $(node -p 'process.versions.node.split(".")[0]') == 22 ]]
[[ $(git -C "$REPO" rev-parse HEAD) == "$BASE" ]]
[[ -z $(git -C "$REPO" status --porcelain) ]]
WORK=$(mktemp -d); DB=""; cleanup(){ if [[ -n $DB ]]; then docker rm -f "$DB" >/dev/null 2>&1 || true; fi; rm -rf "$WORK"; };trap cleanup EXIT
# Clean isolated checkout; do not alter the user's existing source tree.
git clone --quiet --no-local --no-hardlinks "$REPO" "$WORK/source"
git -C "$WORK/source" checkout --quiet --detach "$BASE"
SRC="$WORK/source"
# Same pinned top-level packages as prior isolated source workflow. No deploy or lifecycle script.
npm install --prefix "$WORK/deps" --no-save --ignore-scripts --no-audit --no-fund esbuild@0.25.5 @supabase/supabase-js@2.49.4
ln -s "$WORK/deps/node_modules" "$SRC/node_modules"
printf '\n/node_modules\n' >> "$SRC/.git/info/exclude"
node --test "$ROOT/qa/contract.test.cjs"
node "$ROOT/integration/assemble-review.cjs" "$SRC" "$WORK/output"
# Original source must remain untouched.
git -C "$SRC" diff --exit-code; [[ -z $(git -C "$SRC" status --porcelain) ]]
for mode in stage prod; do
 DB=$(docker run -d --rm --network none -e POSTGRES_PASSWORD=disposable_qa_only -e POSTGRES_DB=aurea_fixture postgres:17)
 for i in $(seq 1 60); do if docker exec "$DB" pg_isready -h 127.0.0.1 -U postgres -d aurea_fixture >/dev/null 2>&1; then break; fi; sleep 1; done
 sql(){ docker exec -i "$DB" psql -X -v ON_ERROR_STOP=1 -U postgres -d aurea_fixture "$@"; }
 [[ $(sql -Atc "SELECT current_setting('server_version_num')::int/10000") == 17 ]]
 [[ $(sql -Atc 'SELECT current_database()') == aurea_fixture ]]
 sql < "$ROOT/qa/disposable-baseline.sql"
 sql < "$ROOT/qa/disposable-access-baseline.sql"
 for f in step6-candidate.sql step5-lifecycle.review.sql billing.review.sql; do sql < "$SRC/architecture/commercial/$f";done
 if [[ $mode == prod ]]; then sql < "$ROOT/qa/disposable-prod-gates.sql";sql < "$ROOT/qa/disposable-prod-schedule.sql";fi
 sql -At < "$ROOT/database/history.readonly.sql" > "$WORK/history.before"
 sql < "$ROOT/database/micro.review.sql"
 sql < "$ROOT/database/micro.synthetic.sql"
 sql < "$ROOT/qa/extra.synthetic.sql"
 sql < "$ROOT/qa/scheduler.synthetic.sql"
 sql < "$ROOT/qa/access.synthetic.sql"
 if [[ $mode == prod ]]; then sql < "$ROOT/qa/prod-access.synthetic.sql";fi
 sql -At < "$ROOT/database/history.readonly.sql" > "$WORK/history.after";cmp "$WORK/history.before" "$WORK/history.after"
 # Concurrent last seat: one transaction must fail. Exact run-owned fixture only.
 sql -c "INSERT INTO aurea_private.organizations(id,name) VALUES('00000000-0000-4000-8000-000000000088','QA concurrent'); INSERT INTO aurea_commercial.accounts(organization_id,seats) VALUES('00000000-0000-4000-8000-000000000088',1);"
 (sql -c "BEGIN; INSERT INTO aurea_delivery_rpc.active_recipients(organization_id,email) VALUES('00000000-0000-4000-8000-000000000088','first@example.invalid'); SELECT pg_sleep(2); COMMIT;" > "$WORK/concurrent.first" 2>&1)& pid=$!
 sleep .3
 if sql -c "INSERT INTO aurea_delivery_rpc.active_recipients(organization_id,email) VALUES('00000000-0000-4000-8000-000000000088','second@example.invalid');" > "$WORK/concurrent.second" 2>&1; then echo 'Concurrent overbooking accepted' >&2;exit 1;fi
 wait "$pid"
 grep -q 'Licensed capacity exceeded or account missing' "$WORK/concurrent.second"
 [[ $(sql -Atc "SELECT aurea_commercial.licensed_count_v1('00000000-0000-4000-8000-000000000088')") == 1 ]]
 if sql < "$ROOT/database/micro.rollback.sql" > "$WORK/guard" 2>&1;then echo 'Unsafe rollback accepted' >&2;exit 1;fi
 grep -q 'Rollback prohibited' "$WORK/guard"
 sql -c "DELETE FROM aurea_delivery_rpc.active_recipients WHERE organization_id='00000000-0000-4000-8000-000000000088'; DELETE FROM aurea_commercial.accounts WHERE organization_id='00000000-0000-4000-8000-000000000088'; DELETE FROM aurea_private.organizations WHERE id='00000000-0000-4000-8000-000000000088';"
 sql < "$ROOT/database/micro.rollback.sql"
 sql -At < "$ROOT/database/history.readonly.sql" > "$WORK/history.rollback";cmp "$WORK/history.before" "$WORK/history.rollback"
 echo "PASS $mode fixture migration, targeted tests, concurrent seat, guarded rollback and history parity"
 docker rm -f "$DB" >/dev/null;DB=""
done
echo 'Disposable runner complete. Still require full real Auth/route/browser build acceptance before live migration/deployment.'
