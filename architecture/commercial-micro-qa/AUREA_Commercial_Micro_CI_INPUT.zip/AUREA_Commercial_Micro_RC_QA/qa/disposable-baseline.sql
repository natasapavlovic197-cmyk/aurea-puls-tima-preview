-- Disposable PG17 only, minimal schema contract. Never run against Supabase.
-- Commercial tables/functions are installed from the pinned repository scripts by run-isolated.sh.
CREATE ROLE anon NOLOGIN;
CREATE ROLE authenticated NOLOGIN;
CREATE ROLE service_role NOLOGIN;
CREATE SCHEMA auth;
CREATE SCHEMA aurea_private;
CREATE SCHEMA aurea_delivery_rpc;
CREATE SCHEMA aurea_admin;
CREATE FUNCTION auth.jwt() RETURNS jsonb LANGUAGE sql STABLE AS $$ SELECT coalesce(nullif(current_setting('qa.jwt',true),'')::jsonb,'{}'::jsonb) $$;
CREATE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql STABLE AS $$ SELECT nullif(auth.jwt()->>'sub','')::uuid $$;
GRANT USAGE ON SCHEMA auth,aurea_admin TO authenticated;
CREATE TABLE auth.users(id uuid PRIMARY KEY,email text,email_confirmed_at timestamptz,deleted_at timestamptz,banned_until timestamptz,is_anonymous boolean NOT NULL DEFAULT false);
CREATE TABLE auth.sessions(id uuid PRIMARY KEY,user_id uuid REFERENCES auth.users(id),not_after timestamptz);
CREATE TABLE aurea_private.organizations(id uuid PRIMARY KEY DEFAULT gen_random_uuid(),name text NOT NULL,created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE aurea_private.memberships(organization_id uuid REFERENCES aurea_private.organizations(id),user_id uuid REFERENCES auth.users(id),role text CHECK(role IN ('owner','manager')),created_at timestamptz DEFAULT now(),PRIMARY KEY(organization_id,user_id));
CREATE TABLE aurea_private.cycles(id uuid PRIMARY KEY DEFAULT gen_random_uuid(),organization_id uuid REFERENCES aurea_private.organizations(id),week_start date NOT NULL,state text NOT NULL DEFAULT 'draft',created_at timestamptz DEFAULT now(),model_version int NOT NULL DEFAULT 1,UNIQUE(organization_id,week_start));
CREATE TABLE aurea_private.questions(id uuid PRIMARY KEY DEFAULT gen_random_uuid(),code text NOT NULL,domain text NOT NULL,item_version int DEFAULT 1,model_version int DEFAULT 2,active boolean DEFAULT true);
CREATE TABLE aurea_private.cycle_questions(cycle_id uuid REFERENCES aurea_private.cycles(id),question_id uuid REFERENCES aurea_private.questions(id),position smallint,PRIMARY KEY(cycle_id,question_id));
CREATE TABLE aurea_private.invitations(id uuid PRIMARY KEY,cycle_id uuid REFERENCES aurea_private.cycles(id),recipient_address text,token_hash text,expires_at timestamptz,UNIQUE(cycle_id,recipient_address));
CREATE TABLE aurea_private.responses(id uuid PRIMARY KEY DEFAULT gen_random_uuid(),cycle_id uuid REFERENCES aurea_private.cycles(id));
CREATE TABLE aurea_private.response_answers(response_id uuid REFERENCES aurea_private.responses(id),question_id uuid REFERENCES aurea_private.questions(id),rating smallint,not_applicable boolean DEFAULT false,PRIMARY KEY(response_id,question_id));
CREATE TABLE aurea_private.privacy_cycle_seals_v1(cycle_id uuid PRIMARY KEY,organization_id uuid,week_start date);
CREATE TABLE aurea_private.privacy_publications_v1(cycle_id uuid,item_code text,item_version int,domain text,response_count bigint,favorable_percent numeric,PRIMARY KEY(cycle_id,item_code));
CREATE TABLE aurea_private.weekly_report_digests(organization_id uuid,week_start date,digest jsonb,PRIMARY KEY(organization_id,week_start));
CREATE TABLE aurea_private.weekly_delivery_jobs(id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,organization_id uuid,week_start date,action text,status text DEFAULT 'pending',next_attempt_at timestamptz DEFAULT now(),lease_token uuid,lease_expires_at timestamptz,attempt_count int DEFAULT 0,created_at timestamptz DEFAULT now(),updated_at timestamptz DEFAULT now(),UNIQUE(organization_id,week_start,action));
CREATE TABLE aurea_delivery_rpc.identities(user_id uuid PRIMARY KEY REFERENCES auth.users(id));
CREATE TABLE aurea_delivery_rpc.scopes(user_id uuid REFERENCES aurea_delivery_rpc.identities(user_id),organization_id uuid REFERENCES aurea_private.organizations(id),PRIMARY KEY(user_id,organization_id));
CREATE TABLE aurea_delivery_rpc.active_recipients(organization_id uuid REFERENCES aurea_private.organizations(id),id uuid DEFAULT gen_random_uuid(),email text NOT NULL CHECK(email=lower(btrim(email))),active boolean NOT NULL DEFAULT true,PRIMARY KEY(organization_id,id),UNIQUE(organization_id,email));
-- Same function bodies as inspected staging definitions; candidate preflight verifies canonical hashes.
CREATE OR REPLACE FUNCTION aurea_private.privacy_publishable_v1(n bigint, f bigint, invited bigint)
 RETURNS boolean
 LANGUAGE sql
 IMMUTABLE
 SET search_path TO ''
AS $function$
 SELECT coalesce(n>=5 AND n<=invited AND f>=2 AND n-f>=2,false)
$function$;
CREATE OR REPLACE FUNCTION aurea_delivery_rpc.allowed_org(p_org uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO ''
AS $function$ SELECT EXISTS(SELECT 1 FROM aurea_delivery_rpc.scopes s WHERE s.user_id=auth.uid() AND s.organization_id=p_org) $function$;
-- Real scoped identity/session check (no actual Auth server in fixture).
CREATE FUNCTION aurea_delivery_rpc.authorize() RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
BEGIN
 IF auth.uid() IS NULL OR NOT EXISTS(SELECT 1 FROM aurea_delivery_rpc.identities i JOIN auth.sessions s ON s.user_id=i.user_id JOIN auth.users u ON u.id=i.user_id WHERE i.user_id=auth.uid() AND s.id::text=auth.jwt()->>'session_id' AND u.deleted_at IS NULL AND (u.banned_until IS NULL OR u.banned_until<=clock_timestamp()) AND (s.not_after IS NULL OR s.not_after>clock_timestamp())) THEN
  RAISE EXCEPTION 'Delivery access denied' USING ERRCODE='42501';
 END IF;
END $$;
CREATE FUNCTION aurea_delivery_rpc.require_org(p_org uuid) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$ BEGIN PERFORM aurea_delivery_rpc.authorize(); IF NOT aurea_delivery_rpc.allowed_org(p_org) THEN RAISE EXCEPTION 'Delivery scope denied' USING ERRCODE='42501'; END IF; END $$;
CREATE OR REPLACE FUNCTION aurea_private.create_weekly_cycle_v2(p_org uuid, p_week date)
 RETURNS uuid
 LANGUAGE plpgsql
 SET search_path TO ''
AS $function$
declare v_id uuid; v_codes text[]; v_count integer;
begin
if p_week is null or extract(isodow from p_week)<>1 then raise exception 'Monday required'; end if;
v_codes:=array['A_CLARITY','A_WORKLOAD','A_SPEAKUP'] || case (((p_week-date '2026-11-23')/7)%4+4)%4 when 0 then array['R_LEADER_HELP','R_INFO','R_PRIORITY'] when 1 then array['R_COOP','R_TRUST','R_FEEDBACK'] when 2 then array['R_AUTONOMY','R_FAIRNESS','R_RECOGNITION'] else array['R_MEANING','R_RECOVERY','R_RESOURCES'] end;
insert into aurea_private.cycles(organization_id,week_start,model_version,state) values(p_org,p_week,2,'draft') on conflict(organization_id,week_start) do nothing returning id into v_id;
if v_id is null then
 select id into v_id from aurea_private.cycles where organization_id=p_org and week_start=p_week and model_version=2;
 if v_id is null then raise exception 'Legacy cycle conflict'; end if;
 if (select array_agg(q.code order by cq.position) from aurea_private.cycle_questions cq join aurea_private.questions q on q.id=cq.question_id where cq.cycle_id=v_id) is distinct from v_codes then raise exception 'Existing cycle mismatch'; end if;
 return v_id;
end if;
insert into aurea_private.cycle_questions(cycle_id,question_id,position) select v_id,q.id,x.pos::smallint from unnest(v_codes) with ordinality x(code,pos) join aurea_private.questions q on q.code=x.code and q.model_version=2 and q.active;
get diagnostics v_count=row_count;
if v_count<>6 then raise exception 'Incomplete bank'; end if;
return v_id;
end $function$;
CREATE OR REPLACE FUNCTION aurea_delivery_rpc.prepare_monday(p_now timestamp with time zone)
 RETURNS TABLE(organization_id uuid, week_start date, invitation_id uuid, email text, expires_at timestamp with time zone)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
DECLARE w date:=date_trunc('week',p_now AT TIME ZONE 'Europe/Belgrade')::date; o uuid;
BEGIN
 PERFORM aurea_delivery_rpc.authorize();
 IF extract(isodow from p_now AT TIME ZONE 'Europe/Belgrade')<>1 OR extract(hour from p_now AT TIME ZONE 'Europe/Belgrade')<9 THEN RETURN; END IF;
 FOR o IN SELECT s.organization_id FROM aurea_delivery_rpc.scopes s WHERE s.user_id=auth.uid() ORDER BY s.organization_id LOOP
 PERFORM aurea_private.create_weekly_cycle_v2(o,w);
 END LOOP;
 RETURN QUERY SELECT c.organization_id,w,md5(c.id::text||':'||r.id::text)::uuid,r.email,(w+7)::timestamp AT TIME ZONE 'Europe/Belgrade'
 FROM aurea_private.cycles c JOIN aurea_delivery_rpc.active_recipients r ON r.organization_id=c.organization_id AND r.active
 WHERE c.week_start=w AND c.model_version=2 AND c.state='draft' AND aurea_delivery_rpc.allowed_org(c.organization_id);
END $function$;
CREATE OR REPLACE FUNCTION aurea_delivery_rpc.schedule_at(p_now timestamp with time zone)
 RETURNS TABLE(action text, queued integer, not_ready integer)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
DECLARE local_now timestamp:=p_now AT TIME ZONE 'Europe/Belgrade';
 w date:=date_trunc('week',local_now)::date;
 a text; n integer; missing integer;
BEGIN
 PERFORM aurea_delivery_rpc.authorize();
 a:=CASE extract(isodow from local_now) WHEN 1 THEN 'invite' WHEN 3 THEN 'reminder' WHEN 5 THEN 'report' ELSE NULL END;
 IF a IS NULL OR extract(hour from local_now)<9 THEN RETURN; END IF;
 IF a='invite' THEN
 UPDATE aurea_private.cycles c SET state='open' WHERE c.week_start=w AND c.model_version=2 AND c.state='draft' AND aurea_delivery_rpc.allowed_org(c.organization_id)
 AND EXISTS(SELECT 1 FROM aurea_delivery_rpc.active_recipients r WHERE r.organization_id=c.organization_id AND r.active)
 AND NOT EXISTS(SELECT 1 FROM aurea_delivery_rpc.active_recipients r WHERE r.organization_id=c.organization_id AND r.active AND NOT EXISTS(SELECT 1 FROM aurea_private.invitations i WHERE i.cycle_id=c.id AND i.recipient_address=r.email AND i.id=md5(c.id::text||':'||r.id::text)::uuid));
 ELSIF a='report' THEN
 UPDATE aurea_private.cycles c SET state='closed' WHERE c.week_start=w AND c.model_version=2 AND c.state='open' AND aurea_delivery_rpc.allowed_org(c.organization_id);
 END IF;
 INSERT INTO aurea_private.weekly_delivery_jobs(organization_id,week_start,action)
 SELECT c.organization_id,w,a FROM aurea_private.cycles c
 WHERE c.week_start=w AND c.model_version=2 AND aurea_delivery_rpc.allowed_org(c.organization_id)
 AND ((a='report' AND c.state='closed') OR (a IN ('invite','reminder') AND c.state='open'))
 ON CONFLICT DO NOTHING;
 GET DIAGNOSTICS n=ROW_COUNT;
 SELECT count(*)::integer INTO missing FROM aurea_delivery_rpc.scopes s
 WHERE s.user_id=auth.uid() AND NOT EXISTS(SELECT 1 FROM aurea_private.cycles c WHERE c.organization_id=s.organization_id AND c.week_start=w AND c.model_version=2 AND ((a='report' AND c.state='closed') OR (a IN ('invite','reminder') AND c.state='open')));
 RETURN QUERY SELECT a,n,missing;
END $function$;
CREATE OR REPLACE FUNCTION aurea_delivery_rpc.impl_issue_hmac_invitation(p_org uuid, p_week date, p_id uuid, p_address text, p_hash text, p_expires timestamp with time zone)
 RETURNS text
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare c uuid; existing aurea_private.invitations%rowtype; inserted uuid; addr text:=lower(btrim(p_address));
begin
 perform aurea_delivery_rpc.require_org(p_org);
 if p_org is null or p_week is null or extract(isodow from p_week)<>1 or p_id is null or addr is null or length(addr)>254 or addr !~ '^[^[:space:]@]+@[^[:space:]@]+[.][^[:space:]@]+$' or p_hash is null or p_hash !~ '^[a-f0-9]{64}$' or p_expires is null or p_expires<=clock_timestamp() or p_expires>(p_week+7)::timestamp at time zone 'Europe/Belgrade' then return 'invalid'; end if;
 select id into c from aurea_private.cycles where organization_id=p_org and week_start=p_week and state in ('draft','open') and model_version=2 for update;
 if not found then return 'unavailable'; end if;
 select * into existing from aurea_private.invitations where cycle_id=c and lower(btrim(recipient_address))=addr;
 if found then
  if existing.id=p_id and existing.token_hash=p_hash and existing.expires_at=p_expires then return 'existing'; end if;
  return 'conflict';
 end if;
 insert into aurea_private.invitations(id,cycle_id,recipient_address,token_hash,expires_at) values(p_id,c,addr,p_hash,p_expires) on conflict do nothing returning id into inserted;
 return case when inserted is null then 'conflict' else 'created' end;
end $function$;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA aurea_delivery_rpc FROM PUBLIC,anon,authenticated,service_role;
-- Synthetic legacy data, not a copy of user history.
INSERT INTO aurea_private.organizations(id,name) VALUES('00000000-0000-4000-8000-000000000099','QA LEGACY');
INSERT INTO aurea_private.cycles(id,organization_id,week_start,state,model_version) VALUES('00000000-0000-4000-8000-000000000098','00000000-0000-4000-8000-000000000099','2026-11-16','closed',1);
INSERT INTO aurea_private.questions(code,domain) SELECT x,'qa' FROM unnest(ARRAY['A_CLARITY','A_WORKLOAD','A_SPEAKUP','R_LEADER_HELP','R_INFO','R_PRIORITY','R_COOP','R_TRUST','R_FEEDBACK','R_AUTONOMY','R_FAIRNESS','R_RECOGNITION','R_MEANING','R_RECOVERY','R_RESOURCES']) x;
INSERT INTO aurea_private.responses(id,cycle_id) VALUES('00000000-0000-4000-8000-000000000097','00000000-0000-4000-8000-000000000098');
INSERT INTO aurea_private.cycle_questions SELECT '00000000-0000-4000-8000-000000000098',id,1 FROM aurea_private.questions WHERE code='A_CLARITY';
INSERT INTO aurea_private.response_answers SELECT '00000000-0000-4000-8000-000000000097',id,4,false FROM aurea_private.questions WHERE code='A_CLARITY';
