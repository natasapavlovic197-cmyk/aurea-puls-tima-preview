-- Test-only Auth claims and activation flags in disposable production-shaped PG17.
BEGIN;
DO $qa$
DECLARE o uuid:=gen_random_uuid(); other uuid:=gen_random_uuid(); u uuid:=gen_random_uuid(); sid uuid:=gen_random_uuid(); bad boolean:=false;
BEGIN
 INSERT INTO aurea_private.organizations(id,name) VALUES(o,'QA Micro'),(other,'QA unrelated');
 INSERT INTO aurea_commercial.accounts(organization_id,seats) VALUES(o,1),(other,1);
 INSERT INTO auth.users(id,email,email_confirmed_at) VALUES(u,'qa-micro@example.invalid',now());
 INSERT INTO auth.sessions(id,user_id) VALUES(sid,u);
 INSERT INTO aurea_delivery_rpc.active_recipients(organization_id,email) VALUES(o,'qa-micro@example.invalid');
 PERFORM set_config('qa.jwt',jsonb_build_object('sub',u,'session_id',sid)::text,true);
 BEGIN PERFORM public.aurea_education_access_v1(o); EXCEPTION WHEN insufficient_privilege THEN bad:=true; END;
 IF NOT bad THEN RAISE EXCEPTION 'OFF gate did not deny'; END IF;
 UPDATE aurea_admin.activation_gates_v1 SET enabled=true WHERE role IN ('employee','manager');
 IF NOT public.aurea_education_access_v1(o) OR public.aurea_education_access_v1(other) OR aurea_commercial.pulse_eligible_v1(o) THEN RAISE EXCEPTION 'Micro entitlement or tenant isolation'; END IF;
 INSERT INTO aurea_private.memberships(organization_id,user_id,role) VALUES(o,u,'manager');
 IF aurea_commercial.licensed_count_v1(o)<>1 OR NOT public.aurea_education_access_v1(o) THEN RAISE EXCEPTION 'Owner roster double counted'; END IF;
 UPDATE aurea_commercial.accounts SET suspended=true WHERE organization_id=o;
 IF public.aurea_education_access_v1(o) THEN RAISE EXCEPTION 'Suspended account allowed'; END IF;
 UPDATE aurea_commercial.accounts SET suspended=false,trial_start=now()-interval '744 hours',trial_end=now()-interval '24 hours' WHERE organization_id=o;
 IF public.aurea_education_access_v1(o) THEN RAISE EXCEPTION 'Expired account allowed'; END IF;
 PERFORM aurea_commercial.grant_complimentary(o);
 IF NOT public.aurea_education_access_v1(o) THEN RAISE EXCEPTION 'Gift access denied'; END IF;
 UPDATE auth.sessions SET not_after=now()-interval '1 day' WHERE id=sid;
 IF public.aurea_education_access_v1(o) THEN RAISE EXCEPTION 'Expired session allowed'; END IF;
 RAISE NOTICE 'PASS production-shaped fixture access cases';
END $qa$;
ROLLBACK;
