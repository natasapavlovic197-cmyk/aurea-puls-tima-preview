-- Disposable fixture only: no HTTP, emails or actual accounts. All rows rolled back.
BEGIN;
DO $qa$
DECLARE o uuid:=gen_random_uuid(); u uuid:=gen_random_uuid(); sid uuid:=gen_random_uuid(); r record; w date:=(date_trunc('week',clock_timestamp() AT TIME ZONE 'Europe/Belgrade')::date+7); c uuid; n int; got record; refused boolean:=false;
BEGIN
 INSERT INTO aurea_private.organizations(id,name) VALUES(o,'QA Micro to Workplace');
 INSERT INTO aurea_commercial.accounts(organization_id,seats) VALUES(o,5);
 INSERT INTO auth.users(id,email,email_confirmed_at) VALUES(u,'qa-scheduler@example.invalid',now());
 INSERT INTO auth.sessions(id,user_id) VALUES(sid,u);
 INSERT INTO aurea_delivery_rpc.identities(user_id) VALUES(u);
 INSERT INTO aurea_delivery_rpc.scopes(user_id,organization_id) VALUES(u,o);
 PERFORM set_config('qa.jwt',jsonb_build_object('sub',u,'session_id',sid)::text,true);
 IF to_regclass('aurea_admin.activation_gates_v1') IS NOT NULL THEN
  BEGIN PERFORM aurea_delivery_rpc.prepare_monday((w+time '10:00') AT TIME ZONE 'Europe/Belgrade');EXCEPTION WHEN insufficient_privilege THEN refused:=true;END;
  IF NOT refused THEN RAISE EXCEPTION 'Scheduler OFF gate bypass'; END IF;
  UPDATE aurea_admin.activation_gates_v1 SET enabled=true WHERE role='scheduler';
  INSERT INTO aurea_admin.activation_service_rights_v1 VALUES(u,'scheduler',now()+interval '30 days');
 END IF;
 INSERT INTO aurea_delivery_rpc.active_recipients(organization_id,email) SELECT o,'qa-'||g||'@example.invalid' FROM generate_series(1,4) g;
 SELECT count(*) INTO n FROM aurea_delivery_rpc.prepare_monday((w+time '10:00') AT TIME ZONE 'Europe/Belgrade');
 IF n<>0 OR EXISTS(SELECT 1 FROM aurea_private.cycles WHERE organization_id=o) THEN RAISE EXCEPTION 'Micro cycle created'; END IF;
 SELECT * INTO got FROM aurea_delivery_rpc.schedule_at((w+time '10:00') AT TIME ZONE 'Europe/Belgrade');
 IF got.queued<>0 OR got.not_ready<>0 THEN RAISE EXCEPTION 'Micro queued or wrongly alerted'; END IF;
 INSERT INTO aurea_delivery_rpc.active_recipients(organization_id,email) VALUES(o,'qa-5@example.invalid');
 SELECT count(*) INTO n FROM aurea_delivery_rpc.prepare_monday((w+time '10:00') AT TIME ZONE 'Europe/Belgrade');
 IF n<>5 THEN RAISE EXCEPTION 'Expected 5 eligible recipients: %',n; END IF;
 SELECT id INTO STRICT c FROM aurea_private.cycles WHERE organization_id=o AND week_start=w;
 IF aurea_delivery_rpc.impl_issue_hmac_invitation(o,w,gen_random_uuid(),'intruder@example.invalid',repeat('a',64),(w+7)::timestamp AT TIME ZONE 'Europe/Belgrade')<>'invalid' THEN RAISE EXCEPTION 'Arbitrary invite allowed'; END IF;
 FOR r IN SELECT * FROM aurea_delivery_rpc.prepare_monday((w+time '10:00') AT TIME ZONE 'Europe/Belgrade') LOOP
  IF aurea_delivery_rpc.impl_issue_hmac_invitation(o,w,r.invitation_id,r.email,md5(r.invitation_id::text)||md5(r.invitation_id::text),r.expires_at)<>'created' THEN RAISE EXCEPTION 'Roster invitation failed'; END IF;
  IF aurea_delivery_rpc.impl_issue_hmac_invitation(o,w,r.invitation_id,r.email,md5(r.invitation_id::text)||md5(r.invitation_id::text),r.expires_at)<>'existing' THEN RAISE EXCEPTION 'Invitation replay failed'; END IF;
 END LOOP;
 SELECT * INTO got FROM aurea_delivery_rpc.schedule_at((w+time '10:00') AT TIME ZONE 'Europe/Belgrade');
 IF got.queued<>1 OR got.not_ready<>0 OR (SELECT state FROM aurea_private.cycles WHERE id=c)<>'open' THEN RAISE EXCEPTION 'Eligible cycle not queued'; END IF;
 UPDATE aurea_delivery_rpc.active_recipients SET active=false WHERE organization_id=o AND email='qa-5@example.invalid';
 IF aurea_delivery_rpc.allowed_org(o) THEN RAISE EXCEPTION 'Downgrade still has delivery scope'; END IF;
 SELECT * INTO got FROM aurea_delivery_rpc.schedule_at((w+2+time '10:00') AT TIME ZONE 'Europe/Belgrade');
 IF got.queued<>0 OR got.not_ready<>0 THEN RAISE EXCEPTION 'Micro reminder queued'; END IF;
 SELECT * INTO got FROM aurea_delivery_rpc.schedule_at((w+4+time '10:00') AT TIME ZONE 'Europe/Belgrade');
 IF got.queued<>0 OR got.not_ready<>0 OR (SELECT state FROM aurea_private.cycles WHERE id=c)<>'closed' THEN RAISE EXCEPTION 'Downgraded cycle not safely closed'; END IF;
 RAISE NOTICE 'PASS fixture scheduler, deterministic invite, Micro suppression, downgrade closure';
END $qa$;
ROLLBACK;
