-- Only disposable QA. Run with migration installed; all records rolled back.
BEGIN;
DO $qa$
DECLARE a uuid:=gen_random_uuid(); b uuid:=gen_random_uuid(); i uuid; d timestamptz; blocked boolean:=false;
BEGIN
 INSERT INTO aurea_private.organizations(id,name) VALUES(a,'QA RSD'),(b,'QA other tenant');
 INSERT INTO aurea_commercial.accounts(organization_id,seats,renewal_plan) VALUES(a,2,'annual'),(b,2,'annual');
 i:=aurea_billing.issue(a,'annual','RSD',117.25,current_date,'bank');
 IF (SELECT amount_minor FROM aurea_billing.orders WHERE invoice_id=i)<>703500 THEN RAISE EXCEPTION 'RSD quote mismatch'; END IF;
 BEGIN PERFORM aurea_billing.settle(b,i,'bank','QA-other',703500,'RSD'); EXCEPTION WHEN no_data_found THEN blocked:=true; END;
 IF NOT blocked THEN RAISE EXCEPTION 'Cross-tenant settlement accepted'; END IF;
 blocked:=false;BEGIN PERFORM aurea_billing.settle(a,i,'bank','QA-rsd',703499,'RSD'); EXCEPTION WHEN raise_exception THEN blocked:=true; END;
 IF NOT blocked THEN RAISE EXCEPTION 'Incorrect amount accepted'; END IF;
 IF aurea_billing.settle(a,i,'bank','QA-rsd',703500,'RSD')<>'settled' THEN RAISE EXCEPTION 'Settlement not confirmed'; END IF;
 SELECT paid_until INTO d FROM aurea_commercial.accounts WHERE organization_id=a;
 IF aurea_billing.settle(a,i,'bank','QA-rsd',703500,'RSD')<>'duplicate' OR (SELECT paid_until FROM aurea_commercial.accounts WHERE organization_id=a) IS DISTINCT FROM d THEN RAISE EXCEPTION 'Duplicate settlement'; END IF;
 IF (SELECT count(*) FROM aurea_commercial.payments WHERE invoice_id=i)<>1 THEN RAISE EXCEPTION 'Duplicate receipt'; END IF;
 RAISE NOTICE 'PASS RSD settlement, wrong company/amount, idempotent receipt';
END $qa$;
ROLLBACK;
