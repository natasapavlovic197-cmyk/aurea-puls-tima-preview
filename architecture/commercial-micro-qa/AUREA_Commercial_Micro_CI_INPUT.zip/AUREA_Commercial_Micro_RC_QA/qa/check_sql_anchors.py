"""Static, byte-exact review of captured function bodies and reversible patch anchors. Not SQL execution."""
from pathlib import Path
import re,hashlib
root=Path(__file__).resolve().parents[1]
def funcs(file):
    s=file.read_text()
    return {m.group(1):m.group(0)[:-1]+'\n' for m in re.finditer(r'CREATE OR REPLACE FUNCTION ([\w.]+)\(.*?AS \$function\$.*?\$function\$;',s,re.S)}
old=funcs(root/'qa/disposable-baseline.sql')
prod={**old,**funcs(root/'qa/disposable-prod-schedule.sql')}
expected={'aurea_private.privacy_publishable_v1':'6707b20337b83c3db4af9433fb042d88','aurea_delivery_rpc.allowed_org':'3df99326df7cd2380bc079ea23d18c11','aurea_delivery_rpc.prepare_monday':'854bdfcfce474bcaab5a350c925af903','aurea_delivery_rpc.schedule_at':'699f617eac38fac403ab76f54901a77e','aurea_delivery_rpc.impl_issue_hmac_invitation':'207994bab4ca27d6aad229e867dcf2c9'}
prod_expected={**expected,'aurea_delivery_rpc.prepare_monday':'7793741fa6750a928b0fdbceac7a75c6','aurea_delivery_rpc.schedule_at':'d69a2906ae682646872d8c0207adb2ab'}
def extract(file,tag):
    t=file.read_text().split('DO $'+tag+'$')[1].split(') AS x(sig,before_text,after_text)')[0]
    return [(a.split('(')[0],b.replace("''","'"),c.replace("''","'")) for a,b,c in re.findall(r"\('((?:''|[^'])*)',\s*'((?:''|[^'])*)',\s*'((?:''|[^'])*)'\)",t)]
forward=extract(root/'database/micro.review.sql','patch');back=extract(root/'database/micro.rollback.sql','restore')
assert len(forward)==len(back)==5
for label,baseline,hashes in [('stage',old,expected),('prod',prod,prod_expected)]:
    for key,value in hashes.items():assert hashlib.md5(baseline[key].encode()).hexdigest()==value,key
    patched=baseline.copy()
    for key,anchor,replacement in forward:
        assert patched[key].count(anchor)==1,(label,key,'forward')
        patched[key]=patched[key].replace(anchor,replacement)
    for key,anchor,replacement in back:
        assert patched[key].count(anchor)==1,(label,key,'rollback')
        patched[key]=patched[key].replace(anchor,replacement)
    assert patched==baseline
    print(f'PASS {label}: 5 baseline hashes + 5 forward anchors + 5 rollback anchors; exact text restored')
print('Static verification only. PostgreSQL engine, DDL and runtime ACL have not been tested.')
# Additional actual commercial access gap. Exact seven captured definitions and reverse source patches.
import json
base=funcs(root/'qa/disposable-access-baseline.sql')
expected=json.loads((root/'qa/access-hashes.json').read_text())
for f in expected:
    name=f['signature'].split('(')[0]
    assert hashlib.md5(base[name].encode()).hexdigest()==f['baseline'],name
patched=base.copy()
for file,tag,direction in [(root/'database/micro.review.sql','access_patch','candidate'),(root/'database/micro.rollback.sql','access_restore','baseline')]:
    t=file.read_text().split('DO $'+tag+'$')[1].split(') x(sig,before_hash,after_hash,before_text,after_text)')[0]
    p=re.findall(r"\('((?:''|[^'])*)',\s*'([0-9a-f]{32})',\s*'([0-9a-f]{32})',\s*'((?:''|[^'])*)',\s*'((?:''|[^'])*)'\)",t)
    assert len(p)==7
    for sig,before,after,a,b in p:
        k=sig.split('(')[0];a=a.replace("''","'");b=b.replace("''","'")
        assert hashlib.md5(patched[k].encode()).hexdigest()==before,k
        assert patched[k].count(a)==1,k
        patched[k]=patched[k].replace(a,b)
        assert hashlib.md5(patched[k].encode()).hexdigest()==after,k
    print(f'PASS commercial access: 7 {direction} hash/anchor checks')
assert patched==base
