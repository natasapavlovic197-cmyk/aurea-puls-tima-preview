-- Only disposable QA; no real Auth or mail. Roll back all synthetic rows.
BEGIN;
DO $qa$
DECLARE o uuid:=gen_random_uuid(); b uuid:=gen_random_uuid(); u uuid:=gen_random_uuid(); sid uuid:=gen_random_uuid(); c uuid; w date:=(date_trunc('week',clock_timestamp() AT TIME ZONE 'Europe/Belgrade')::date+7); denied boolean:=false; h text:=repeat('b',64); answer jsonb; n bigint;
BEGIN
 INSERT INTO aurea_private.organizations(id,name) VALUES(o,'QA license access'),(b,'QA other');
 INSERT INTO aurea_commercial.accounts(organization_id,seats) VALUES(o,5),(b,1);
 INSERT INTO auth.users(id,email,email_confirmed_at) VALUES(u,'qa-1@example.invalid',now());
 INSERT INTO auth.sessions(id,user_id) VALUES(sid,u);
 INSERT INTO aurea_private.memberships(organization_id,user_id,role) VALUES(o,u,'manager');
 INSERT INTO aurea_delivery_rpc.active_recipients(organization_id,email) SELECT o,'qa-'||g||'@example.invalid' FROM generate_series(1,5) g;
 PERFORM set_config('qa.jwt',jsonb_build_object('sub',u,'session_id',sid)::text,true);
 IF to_regclass('aurea_admin.activation_gates_v1') IS NOT NULL THEN UPDATE aurea_admin.activation_gates_v1 SET enabled=true WHERE role='manager';END IF;
 PERFORM aurea_manager_rpc.aurea_manager_actions(o);PERFORM aurea_manager_rpc.aurea_manager_cycles(o);PERFORM aurea_manager_rpc.aurea_manager_summary(o);PERFORM aurea_private.manager_publications_v2(o);
 PERFORM aurea_manager_rpc.aurea_manager_save_action(o,'Synthetic follow-up');
 BEGIN PERFORM aurea_manager_rpc.aurea_manager_actions(b);EXCEPTION WHEN insufficient_privilege THEN denied:=true;END;
 IF NOT denied THEN RAISE EXCEPTION 'Cross-tenant manager access';END IF;
 c:=aurea_private.create_weekly_cycle_v2(o,w); UPDATE aurea_private.cycles SET state='open' WHERE id=c;
 INSERT INTO aurea_private.invitations(id,cycle_id,recipient_address,token_hash,expires_at) VALUES(gen_random_uuid(),c,'qa-1@example.invalid',h,(w+7)::timestamp AT TIME ZONE 'Europe/Belgrade');
 IF public.aurea_employee_invitation(h)->>'status'<>'ready' THEN RAISE EXCEPTION 'Eligible pulse blocked';END IF;
 SELECT jsonb_agg(jsonb_build_object('code',q.code,'rating',4) ORDER BY cq.position) INTO answer FROM aurea_private.cycle_questions cq JOIN aurea_private.questions q ON q.id=cq.question_id WHERE cq.cycle_id=c;
 UPDATE aurea_delivery_rpc.active_recipients SET active=false WHERE organization_id=o AND email='qa-5@example.invalid';
 IF public.aurea_employee_invitation(h)->>'status'<>'unavailable' OR public.aurea_employee_submit(h,answer)->>'status'<>'unavailable' THEN RAISE EXCEPTION 'Previously issued token bypassed Micro downgrade';END IF;
 PERFORM aurea_manager_rpc.aurea_manager_cycles(o); -- active Micro may still access closed historical aggregates, not new pulse.
 UPDATE aurea_delivery_rpc.active_recipients SET active=true WHERE organization_id=o AND email='qa-5@example.invalid';
 UPDATE aurea_commercial.accounts SET suspended=true WHERE organization_id=o;
 IF public.aurea_employee_invitation(h)->>'status'<>'unavailable' OR public.aurea_employee_submit(h,answer)->>'status'<>'unavailable' THEN RAISE EXCEPTION 'Suspended pulse access';END IF;
 denied:=false;BEGIN PERFORM aurea_manager_rpc.aurea_manager_actions(o);EXCEPTION WHEN insufficient_privilege THEN denied:=true;END;IF NOT denied THEN RAISE EXCEPTION 'Suspended manager actions';END IF;
 denied:=false;BEGIN PERFORM aurea_manager_rpc.aurea_manager_cycles(o);EXCEPTION WHEN insufficient_privilege THEN denied:=true;END;IF NOT denied THEN RAISE EXCEPTION 'Suspended manager cycles';END IF;
 denied:=false;BEGIN PERFORM aurea_manager_rpc.aurea_manager_summary(o);EXCEPTION WHEN insufficient_privilege THEN denied:=true;END;IF NOT denied THEN RAISE EXCEPTION 'Suspended manager summary';END IF;
 denied:=false;BEGIN PERFORM aurea_private.manager_publications_v2(o);EXCEPTION WHEN insufficient_privilege THEN denied:=true;END;IF NOT denied THEN RAISE EXCEPTION 'Suspended manager publications';END IF;
 denied:=false;BEGIN PERFORM aurea_manager_rpc.aurea_manager_save_action(o,'Synthetic denied');EXCEPTION WHEN insufficient_privilege THEN denied:=true;END;IF NOT denied THEN RAISE EXCEPTION 'Suspended manager write';END IF;
 UPDATE aurea_commercial.accounts SET suspended=false WHERE organization_id=o;
 IF public.aurea_employee_submit(h,answer)->>'status'<>'submitted' THEN RAISE EXCEPTION 'Reactivation not restored';END IF;
 SELECT count(*) INTO n FROM aurea_private.responses WHERE cycle_id=c;
 IF n<>1 OR public.aurea_employee_submit(h,answer)->>'status'<>'unavailable' THEN RAISE EXCEPTION 'Response replay accepted';END IF;
 RAISE NOTICE 'PASS fixture commercial access, downgrade, suspension, manager isolation and one-time response';
END $qa$;
ROLLBACK;
