-- Exact affected function bodies captured read-only. Minimal tables/session stubs are test-only.
CREATE SCHEMA aurea_manager_rpc;
GRANT USAGE ON SCHEMA aurea_manager_rpc,aurea_private TO authenticated;
ALTER TABLE aurea_private.invitations ADD COLUMN redeemed_at timestamptz;
ALTER TABLE aurea_private.questions ADD COLUMN wording text NOT NULL DEFAULT 'Synthetic QA wording';
CREATE TABLE aurea_private.manager_actions(id uuid PRIMARY KEY DEFAULT gen_random_uuid(),organization_id uuid,cycle_id uuid,created_by uuid,description text,due_on date,status text,created_at timestamptz DEFAULT now(),updated_at timestamptz DEFAULT now());
CREATE FUNCTION aurea_manager_rpc.check_session_and_limit() RETURNS void LANGUAGE plpgsql AS $$ BEGIN IF to_regprocedure('aurea_admin.require_activation_v1(text)') IS NOT NULL THEN PERFORM aurea_admin.require_activation_v1('manager'); END IF; IF NOT EXISTS(SELECT 1 FROM auth.sessions s WHERE s.user_id=auth.uid() AND s.id::text=auth.jwt()->>'session_id' AND (s.not_after IS NULL OR s.not_after>now())) THEN RAISE EXCEPTION 'Session denied' USING ERRCODE='42501'; END IF; END $$;
-- No change to real pulse_summary, not tested by this minimal fixture; only authorization boundary.
CREATE FUNCTION aurea_private.pulse_summary(uuid,integer) RETURNS TABLE(week_start date,question_code text,domain text,response_count bigint,favorable_percent numeric) LANGUAGE sql AS $$ SELECT null::date,null::text,null::text,null::bigint,null::numeric WHERE false $$;
CREATE OR REPLACE FUNCTION aurea_manager_rpc.aurea_manager_actions(p_organization_id uuid)
 RETURNS TABLE(id uuid, cycle_id uuid, description text, due_on date, status text, created_at timestamp with time zone)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
begin
 perform aurea_manager_rpc.check_session_and_limit();
 if (select auth.uid()) is null or not exists(select 1 from aurea_private.memberships m where m.user_id=(select auth.uid()) and m.organization_id=p_organization_id and m.role in ('owner','manager')) then raise exception 'Access denied' using errcode='42501';end if;
 return query select a.id,a.cycle_id,a.description,a.due_on,a.status,a.created_at from aurea_private.manager_actions a where a.organization_id=p_organization_id order by a.created_at desc limit 100;
end $function$;
CREATE OR REPLACE FUNCTION aurea_manager_rpc.aurea_manager_cycles(p_organization_id uuid)
 RETURNS TABLE(cycle_id uuid, week_start date, state text)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
begin
 perform aurea_manager_rpc.check_session_and_limit();
 if (select auth.uid()) is null or not exists(select 1 from aurea_private.memberships m where m.user_id=(select auth.uid()) and m.organization_id=p_organization_id and m.role in ('owner','manager')) then raise exception 'Access denied' using errcode='42501';end if;
 return query select c.id,c.week_start,c.state from aurea_private.cycles c where c.organization_id=p_organization_id and c.state='closed' order by c.week_start desc limit 52;
end $function$;
CREATE OR REPLACE FUNCTION aurea_manager_rpc.aurea_manager_save_action(p_organization_id uuid, p_description text, p_due_on date DEFAULT NULL::date, p_cycle_id uuid DEFAULT NULL::uuid, p_action_id uuid DEFAULT NULL::uuid, p_status text DEFAULT 'open'::text)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare result uuid;
begin
 perform aurea_manager_rpc.check_session_and_limit();
 if (select auth.uid()) is null or not exists(select 1 from aurea_private.memberships m where m.user_id=(select auth.uid()) and m.organization_id=p_organization_id and m.role in ('owner','manager')) then raise exception 'Access denied' using errcode='42501';end if;
 if length(trim(coalesce(p_description,''))) not between 3 and 2000 or p_status is null or p_status not in ('open','done') then raise exception 'Invalid action';end if;
 if p_cycle_id is not null and not exists(select 1 from aurea_private.cycles c where c.id=p_cycle_id and c.organization_id=p_organization_id) then raise exception 'Invalid cycle';end if;
 if p_action_id is null then
 insert into aurea_private.manager_actions(organization_id,cycle_id,created_by,description,due_on,status)
 values(p_organization_id,p_cycle_id,(select auth.uid()),trim(p_description),p_due_on,p_status) returning id into result;
 else
 update aurea_private.manager_actions a set description=trim(p_description),due_on=p_due_on,status=p_status,updated_at=now()
 where a.id=p_action_id and a.organization_id=p_organization_id returning a.id into result;
 if result is null then raise exception 'Action not found';end if;
 end if;
 return result;
end $function$;
CREATE OR REPLACE FUNCTION aurea_manager_rpc.aurea_manager_summary(p_organization_id uuid)
 RETURNS TABLE(week_start date, question_code text, domain text, response_count bigint, favorable_percent numeric)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
begin
 perform aurea_manager_rpc.check_session_and_limit();
 if (select auth.uid()) is null then raise exception 'Authentication required' using errcode='28000'; end if;
 if not exists(select 1 from aurea_private.memberships m where m.organization_id=p_organization_id and m.user_id=(select auth.uid()) and m.role in ('owner','manager')) then
 raise exception 'Access denied' using errcode='42501';
 end if;
 return query select s.week_start,s.question_code,s.domain,s.response_count,s.favorable_percent from aurea_private.pulse_summary(p_organization_id,5) s;
end $function$;
CREATE OR REPLACE FUNCTION aurea_private.manager_publications_v2(p_org uuid)
 RETURNS TABLE(week_start date, item_code text, item_version integer, domain text, response_count bigint, favorable_percent numeric, closed boolean)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
begin
 perform aurea_manager_rpc.check_session_and_limit();
if auth.uid() is null or not exists(select 1 from aurea_private.memberships m where m.organization_id=p_org and m.user_id=auth.uid() and m.role in ('owner','manager')) then raise exception 'Access denied' using errcode='42501'; end if;
RETURN QUERY SELECT s.week_start,p.item_code,p.item_version,p.domain,p.response_count,p.favorable_percent,true FROM aurea_private.privacy_cycle_seals_v1 s JOIN aurea_private.privacy_publications_v1 p ON p.cycle_id=s.cycle_id WHERE s.organization_id=p_org ORDER BY s.week_start,p.item_code;
end $function$;
CREATE OR REPLACE FUNCTION public.aurea_employee_invitation(p_hash text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare v_inv record; v_questions jsonb;
begin
 if p_hash is null or p_hash !~ '^[0-9a-f]{64}$' then return jsonb_build_object('status','invalid'); end if;
 select i.id,i.cycle_id,i.redeemed_at,i.expires_at,c.state into v_inv
 from aurea_private.invitations i join aurea_private.cycles c on c.id=i.cycle_id
 where i.token_hash=p_hash;
 if not found or v_inv.redeemed_at is not null or v_inv.expires_at<=now() or v_inv.state<>'open' then
 return jsonb_build_object('status','unavailable');end if;
 select jsonb_agg(jsonb_build_object('code',q.code,'wording',q.wording,'position',cq.position) order by cq.position) into v_questions
 from aurea_private.cycle_questions cq join aurea_private.questions q on q.id=cq.question_id
 where cq.cycle_id=v_inv.cycle_id and q.active;
 return jsonb_build_object('status','ready','questions',coalesce(v_questions,'[]'::jsonb));
end $function$;
CREATE OR REPLACE FUNCTION public.aurea_employee_submit(p_hash text, p_answers jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare v_inv record; v_count int; v_resp uuid; v_item jsonb; v_question record; v_rating int; v_na boolean;
begin
 if p_hash is null or p_hash !~ '^[0-9a-f]{64}$' then return jsonb_build_object('status','invalid');end if;
 if p_answers is null or jsonb_typeof(p_answers)<>'array' then return jsonb_build_object('status','invalid_answers');end if;
 select i.id,i.cycle_id,i.redeemed_at,i.expires_at,c.state,c.model_version into v_inv
 from aurea_private.invitations i join aurea_private.cycles c on c.id=i.cycle_id
 where i.token_hash=p_hash for update of i,c;
 if not found or v_inv.redeemed_at is not null or v_inv.expires_at<=now() or v_inv.state<>'open' then
 return jsonb_build_object('status','unavailable');end if;
 select count(*) into v_count from aurea_private.cycle_questions where cycle_id=v_inv.cycle_id;
 if v_count<>(case when v_inv.model_version=1 then 4 when v_inv.model_version=2 then 6 else -1 end) then return jsonb_build_object('status','unavailable');end if;
 if jsonb_array_length(p_answers)<>v_count or (select count(distinct a->>'code') from jsonb_array_elements(p_answers) a)<>v_count then return jsonb_build_object('status','invalid_answers');end if;
 for v_item in select value from jsonb_array_elements(p_answers) loop
   if jsonb_typeof(v_item)<>'object' or (v_item->>'code') is null or (v_item->>'rating') is null
     or (v_item->>'rating') !~ '^[1-6]$' then return jsonb_build_object('status','invalid_answers');end if;
   if not exists(select 1 from aurea_private.cycle_questions cq join aurea_private.questions q on q.id=cq.question_id where cq.cycle_id=v_inv.cycle_id and q.code=v_item->>'code') then return jsonb_build_object('status','invalid_answers');end if;
 end loop;
 insert into aurea_private.responses(cycle_id) values(v_inv.cycle_id) returning id into v_resp;
 for v_item in select value from jsonb_array_elements(p_answers) loop
   select q.id into v_question from aurea_private.questions q where q.code=v_item->>'code';
   v_rating=(v_item->>'rating')::int;v_na=(v_rating=6);
   insert into aurea_private.response_answers(response_id,question_id,rating,not_applicable)
   values(v_resp,v_question.id,case when v_na then null else v_rating end,v_na);
 end loop;
 update aurea_private.invitations set redeemed_at=now() where id=v_inv.id;
 return jsonb_build_object('status','submitted');
end $function$;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA aurea_manager_rpc FROM PUBLIC,anon,authenticated,service_role;
GRANT EXECUTE ON FUNCTION aurea_manager_rpc.aurea_manager_actions(uuid),aurea_manager_rpc.aurea_manager_cycles(uuid),aurea_manager_rpc.aurea_manager_save_action(uuid,text,date,uuid,uuid,text),aurea_manager_rpc.aurea_manager_summary(uuid) TO authenticated;
REVOKE ALL ON FUNCTION aurea_private.manager_publications_v2(uuid),public.aurea_employee_invitation(text),public.aurea_employee_submit(text,jsonb) FROM PUBLIC,anon,authenticated,service_role;
GRANT EXECUTE ON FUNCTION aurea_private.manager_publications_v2(uuid) TO authenticated;
