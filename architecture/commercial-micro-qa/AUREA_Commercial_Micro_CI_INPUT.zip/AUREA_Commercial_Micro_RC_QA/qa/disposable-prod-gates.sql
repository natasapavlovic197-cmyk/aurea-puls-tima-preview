-- Test-only production-shaped gate structure; not an Auth server or production clone.
CREATE TABLE aurea_admin.activation_gates_v1(role text PRIMARY KEY,enabled boolean NOT NULL DEFAULT false);
INSERT INTO aurea_admin.activation_gates_v1(role) SELECT unnest(ARRAY['adminRead','adminWrite','billingWrite','delivery','employee','manager','scheduler']);
CREATE TABLE aurea_admin.activation_operator_rights_v1(user_id uuid,role text,expires_at timestamptz,PRIMARY KEY(user_id,role));
CREATE TABLE aurea_admin.auth_operators(user_id uuid PRIMARY KEY,enabled boolean,expires_at timestamptz);
CREATE TABLE aurea_admin.activation_service_rights_v1(user_id uuid,role text,expires_at timestamptz,PRIMARY KEY(user_id,role));
CREATE FUNCTION aurea_admin.require_operator() RETURNS void LANGUAGE plpgsql AS $$ BEGIN RAISE EXCEPTION 'No operators in disposable fixture' USING ERRCODE='42501'; END $$;
CREATE OR REPLACE FUNCTION aurea_admin.require_activation_v1(p_role text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
BEGIN
 IF NOT EXISTS(SELECT 1 FROM aurea_admin.activation_gates_v1 g WHERE g.role=p_role AND g.enabled) THEN
  RAISE EXCEPTION 'Activation denied' USING ERRCODE='42501';
 END IF;
 IF p_role IN ('adminRead','adminWrite','billingWrite') THEN
  PERFORM aurea_admin.require_operator();
  IF auth.jwt()->>'aal' IS DISTINCT FROM 'aal2' OR NOT EXISTS (
   SELECT 1 FROM aurea_admin.activation_operator_rights_v1 r JOIN aurea_admin.auth_operators o ON o.user_id=r.user_id
   WHERE r.user_id=auth.uid() AND r.role=p_role AND r.expires_at>clock_timestamp()
   AND o.enabled AND o.expires_at>clock_timestamp()
  ) THEN RAISE EXCEPTION 'Access denied' USING ERRCODE='42501'; END IF;
 ELSIF p_role IN ('scheduler','delivery') THEN
  IF NOT EXISTS (
   SELECT 1 FROM aurea_admin.activation_service_rights_v1 r
   JOIN aurea_delivery_rpc.identities i ON i.user_id=r.user_id
   JOIN auth.users u ON u.id=r.user_id
   JOIN auth.sessions s ON s.user_id=r.user_id
   WHERE r.user_id=auth.uid() AND r.role=p_role AND r.expires_at>clock_timestamp()
   AND NOT u.is_anonymous AND u.deleted_at IS NULL
   AND (u.banned_until IS NULL OR u.banned_until<=clock_timestamp())
   AND s.id::text=auth.jwt()->>'session_id' AND (s.not_after IS NULL OR s.not_after>clock_timestamp())
   AND (SELECT count(*) FROM aurea_delivery_rpc.scopes sc WHERE sc.user_id=r.user_id)<=1
  ) THEN RAISE EXCEPTION 'Access denied' USING ERRCODE='42501'; END IF;
 END IF;
END $function$;
REVOKE ALL ON ALL TABLES IN SCHEMA aurea_admin FROM PUBLIC,anon,authenticated,service_role;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA aurea_admin FROM PUBLIC,anon,authenticated,service_role;
