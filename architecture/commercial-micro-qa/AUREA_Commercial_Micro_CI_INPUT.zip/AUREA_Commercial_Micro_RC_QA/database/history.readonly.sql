-- Run before and after approved migration; compare exact counts AND content digests. No personal values returned.
SELECT 'cycles' AS source,count(*) AS rows,md5(coalesce(string_agg(md5(to_jsonb(t)::text),',' ORDER BY md5(to_jsonb(t)::text)),'')) AS fingerprint FROM aurea_private.cycles t
UNION ALL SELECT 'cycle_questions',count(*),md5(coalesce(string_agg(md5(to_jsonb(t)::text),',' ORDER BY md5(to_jsonb(t)::text)),'')) FROM aurea_private.cycle_questions t
UNION ALL SELECT 'responses',count(*),md5(coalesce(string_agg(md5(to_jsonb(t)::text),',' ORDER BY md5(to_jsonb(t)::text)),'')) FROM aurea_private.responses t
UNION ALL SELECT 'response_answers',count(*),md5(coalesce(string_agg(md5(to_jsonb(t)::text),',' ORDER BY md5(to_jsonb(t)::text)),'')) FROM aurea_private.response_answers t
UNION ALL SELECT 'privacy_cycle_seals_v1',count(*),md5(coalesce(string_agg(md5(to_jsonb(t)::text),',' ORDER BY md5(to_jsonb(t)::text)),'')) FROM aurea_private.privacy_cycle_seals_v1 t
UNION ALL SELECT 'privacy_publications_v1',count(*),md5(coalesce(string_agg(md5(to_jsonb(t)::text),',' ORDER BY md5(to_jsonb(t)::text)),'')) FROM aurea_private.privacy_publications_v1 t
UNION ALL SELECT 'weekly_report_digests',count(*),md5(coalesce(string_agg(md5(to_jsonb(t)::text),',' ORDER BY md5(to_jsonb(t)::text)),'')) FROM aurea_private.weekly_report_digests t
ORDER BY 1;
