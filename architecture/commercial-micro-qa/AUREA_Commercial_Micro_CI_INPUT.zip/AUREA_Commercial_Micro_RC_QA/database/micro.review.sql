-- AUREA Commercial & Micro — REVIEW ONLY, PG17. No live apply authorized.
-- Base: 7e2908e4e8c234a4bb8056f2017f02c70cfdb7c5 and read-only staging/prod definitions.
-- Must be executed by the approved migration owner, in a single transaction.
BEGIN;
SET LOCAL lock_timeout = '5s';
SET LOCAL statement_timeout = '60s';
-- Quiescent launch window; avoid repricing issued invoices or changing an active delivery flow.
LOCK TABLE aurea_commercial.accounts, aurea_commercial.invoices, aurea_commercial.payments,
 aurea_billing.orders, aurea_delivery_rpc.active_recipients, aurea_delivery_rpc.scopes,
 aurea_private.memberships, aurea_private.weekly_delivery_jobs IN ACCESS EXCLUSIVE MODE;
DO $preflight$
DECLARE expression_text text; fn record; h text;
BEGIN
 IF current_setting('server_version_num')::int NOT BETWEEN 170000 AND 179999 THEN RAISE EXCEPTION 'PG17 expected'; END IF;
 IF EXISTS(SELECT 1 FROM aurea_commercial.accounts) OR EXISTS(SELECT 1 FROM aurea_commercial.invoices)
 OR EXISTS(SELECT 1 FROM aurea_commercial.payments) OR EXISTS(SELECT 1 FROM aurea_billing.orders)
 OR EXISTS(SELECT 1 FROM aurea_delivery_rpc.scopes) OR EXISTS(SELECT 1 FROM aurea_delivery_rpc.active_recipients)
 OR EXISTS(SELECT 1 FROM aurea_private.weekly_delivery_jobs) THEN RAISE EXCEPTION 'Not the reviewed empty commercial/delivery baseline'; END IF;
 IF to_regclass('aurea_admin.activation_gates_v1') IS NOT NULL THEN
   IF EXISTS(SELECT 1 FROM aurea_admin.activation_gates_v1 WHERE enabled) THEN RAISE EXCEPTION 'Activation must remain OFF'; END IF;
 END IF;
 SELECT generation_expression INTO expression_text FROM information_schema.columns
 WHERE table_schema='aurea_commercial' AND table_name='invoices' AND column_name='amount_cents' AND is_generated='ALWAYS';
 IF expression_text IS NULL OR position('3900' IN expression_text)=0 OR position('250' IN expression_text)=0 OR position('300' IN expression_text)=0 THEN RAISE EXCEPTION 'Invoice baseline changed'; END IF;
 FOR fn IN SELECT * FROM (VALUES
 ('aurea_commercial.renewal_quote(uuid,timestamptz)','148ae557be3e8f6a4dcbe0dd67a3ca12','148ae557be3e8f6a4dcbe0dd67a3ca12'),
 ('aurea_delivery_rpc.allowed_org(uuid)','3df99326df7cd2380bc079ea23d18c11','3df99326df7cd2380bc079ea23d18c11'),
 ('aurea_delivery_rpc.prepare_monday(timestamptz)','854bdfcfce474bcaab5a350c925af903','7793741fa6750a928b0fdbceac7a75c6'),
 ('aurea_delivery_rpc.schedule_at(timestamptz)','699f617eac38fac403ab76f54901a77e','d69a2906ae682646872d8c0207adb2ab'),
 ('aurea_delivery_rpc.impl_issue_hmac_invitation(uuid,date,uuid,text,text,timestamptz)','207994bab4ca27d6aad229e867dcf2c9','207994bab4ca27d6aad229e867dcf2c9'),
 ('aurea_private.privacy_publishable_v1(bigint,bigint,bigint)','6707b20337b83c3db4af9433fb042d88','6707b20337b83c3db4af9433fb042d88')
 ) AS x(sig,stage_hash,prod_hash) LOOP
 SELECT md5(pg_get_functiondef(to_regprocedure(fn.sig))) INTO h;
 IF h IS DISTINCT FROM CASE WHEN to_regclass('aurea_admin.activation_gates_v1') IS NULL THEN fn.stage_hash ELSE fn.prod_hash END THEN RAISE EXCEPTION 'Baseline changed: %',fn.sig; END IF;
 END LOOP;
END $preflight$;
-- PG17 rewrites generated values: empty-invoice check above is intentional.
ALTER TABLE aurea_commercial.invoices ALTER COLUMN amount_cents SET EXPRESSION AS
 (CASE WHEN plan='annual' THEN seats::bigint*3000 ELSE seats::bigint*300 END);
CREATE OR REPLACE FUNCTION aurea_commercial.renewal_quote(p_org uuid,p_at timestamptz DEFAULT now())
RETURNS TABLE(organization_id uuid,plan text,seats integer,amount_cents bigint,currency text,charge_performed boolean)
LANGUAGE sql STABLE SECURITY INVOKER SET search_path='' AS $function$
 SELECT a.organization_id,a.renewal_plan,a.seats,
 CASE WHEN a.renewal_plan='annual' THEN a.seats::bigint*3000 ELSE a.seats::bigint*300 END,
 'EUR'::text,false
 FROM aurea_commercial.accounts a
 WHERE a.organization_id=p_org AND a.renewal_enabled AND NOT a.complimentary AND NOT a.suspended
 AND a.paid_until IS NOT NULL AND a.paid_until<=p_at
 AND NOT EXISTS(SELECT 1 FROM aurea_commercial.invoices i WHERE i.organization_id=a.organization_id AND i.paid_at IS NULL AND i.cancelled_at IS NULL)
$function$;
-- A paid seat is one distinct roster address or owner/manager Auth identity (same normalized email counts once).
-- This is a proposed commercial counting convention; owner must approve before applying.
CREATE FUNCTION aurea_commercial.licensed_count_v1(p_org uuid) RETURNS bigint
 LANGUAGE sql STABLE SECURITY INVOKER SET search_path='' AS $function$
 SELECT count(*) FROM (
   SELECT r.email AS identity FROM aurea_delivery_rpc.active_recipients r WHERE r.organization_id=p_org AND r.active
   UNION
   SELECT coalesce(nullif(lower(btrim(u.email)),''),'uid:'||u.id::text) FROM aurea_private.memberships m JOIN auth.users u ON u.id=m.user_id
    WHERE m.organization_id=p_org AND m.role IN ('owner','manager') AND u.deleted_at IS NULL
 ) AS licensed
$function$;
CREATE FUNCTION aurea_commercial.pulse_eligible_v1(p_org uuid) RETURNS boolean
 LANGUAGE sql STABLE SECURITY INVOKER SET search_path='' AS $function$
 SELECT coalesce((SELECT aurea_commercial.status(a.organization_id) IN ('trial','active','complimentary')
   AND aurea_commercial.licensed_count_v1(a.organization_id)<=a.seats
   AND (SELECT count(*) FROM aurea_delivery_rpc.active_recipients r WHERE r.organization_id=a.organization_id AND r.active)>=5
 FROM aurea_commercial.accounts a WHERE a.organization_id=p_org),false)
$function$;
-- Serialize additions against the commercial account row. No existing roster rows are modified.
CREATE FUNCTION aurea_commercial.guard_roster_capacity_v1() RETURNS trigger
 LANGUAGE plpgsql SECURITY INVOKER SET search_path='' AS $function$
DECLARE cap integer;
BEGIN
 IF TG_OP='UPDATE' THEN
  IF NEW.organization_id IS DISTINCT FROM OLD.organization_id THEN RAISE EXCEPTION 'Move requires controlled reprovisioning'; END IF;
 END IF;
 IF TG_TABLE_NAME='active_recipients' THEN IF NOT NEW.active THEN RETURN NEW; END IF; END IF;
 -- A no-op update serializes concurrent roster writers (repeatable read may abort and retry).
 UPDATE aurea_commercial.accounts SET seats=seats WHERE organization_id=NEW.organization_id RETURNING seats INTO cap;
 IF NOT FOUND OR aurea_commercial.licensed_count_v1(NEW.organization_id)>cap THEN RAISE EXCEPTION 'Licensed capacity exceeded or account missing' USING ERRCODE='23514'; END IF;
 RETURN NEW;
END $function$;
CREATE FUNCTION aurea_commercial.guard_seat_capacity_v1() RETURNS trigger
 LANGUAGE plpgsql SECURITY INVOKER SET search_path='' AS $function$
BEGIN
 IF aurea_commercial.licensed_count_v1(NEW.organization_id)>NEW.seats THEN RAISE EXCEPTION 'Seat count below provisioned users' USING ERRCODE='23514'; END IF;
 RETURN NEW;
END $function$;
CREATE TRIGGER micro_roster_capacity_v1 AFTER INSERT OR UPDATE ON aurea_delivery_rpc.active_recipients FOR EACH ROW EXECUTE FUNCTION aurea_commercial.guard_roster_capacity_v1();
CREATE TRIGGER micro_membership_capacity_v1 AFTER INSERT OR UPDATE ON aurea_private.memberships FOR EACH ROW EXECUTE FUNCTION aurea_commercial.guard_roster_capacity_v1();
CREATE TRIGGER micro_account_insert_capacity_v1 AFTER INSERT ON aurea_commercial.accounts FOR EACH ROW EXECUTE FUNCTION aurea_commercial.guard_seat_capacity_v1();
CREATE TRIGGER micro_account_update_capacity_v1 BEFORE UPDATE OF seats ON aurea_commercial.accounts FOR EACH ROW WHEN (OLD.seats IS DISTINCT FROM NEW.seats) EXECUTE FUNCTION aurea_commercial.guard_seat_capacity_v1();
REVOKE ALL ON FUNCTION aurea_commercial.licensed_count_v1(uuid),aurea_commercial.pulse_eligible_v1(uuid),aurea_commercial.guard_roster_capacity_v1(),aurea_commercial.guard_seat_capacity_v1() FROM PUBLIC,anon,authenticated,service_role;
-- Extend existing scoped delivery authorization; no additional scope, no gate activation.
-- Source-preserving replacements: exact baseline hashes were checked above. Retain owner, grants, gate differences.
DO $patch$
DECLARE p text; d text; s text; t text; n integer;
BEGIN
 FOR p,s,t IN SELECT * FROM (VALUES
 ('aurea_delivery_rpc.allowed_org(uuid)', 's.organization_id=p_org)', 's.organization_id=p_org) AND aurea_commercial.pulse_eligible_v1(p_org)'),
 ('aurea_delivery_rpc.prepare_monday(timestamptz)', 'WHERE s.user_id=auth.uid() ORDER BY s.organization_id LOOP', 'WHERE s.user_id=auth.uid() AND aurea_delivery_rpc.allowed_org(s.organization_id) ORDER BY s.organization_id LOOP'),
 ('aurea_delivery_rpc.schedule_at(timestamptz)', 'WHERE s.user_id=auth.uid() AND NOT EXISTS', 'WHERE s.user_id=auth.uid() AND aurea_delivery_rpc.allowed_org(s.organization_id) AND NOT EXISTS'),
 -- Friday closes an already-open cycle even if its roster/license became ineligible; new report delivery stays blocked by allowed_org.
 ('aurea_delivery_rpc.schedule_at(timestamptz)', 'c.state=''open'' AND aurea_delivery_rpc.allowed_org(c.organization_id);', 'c.state=''open'' AND EXISTS(SELECT 1 FROM aurea_delivery_rpc.scopes s WHERE s.user_id=auth.uid() AND s.organization_id=c.organization_id);'),
 -- No issuance to arbitrary addresses or arbitrary invitation IDs even within a scoped organization.
 ('aurea_delivery_rpc.impl_issue_hmac_invitation(uuid,date,uuid,text,text,timestamptz)', 'if not found then return ''unavailable''; end if;', 'if not found then return ''unavailable''; end if; IF NOT EXISTS(SELECT 1 FROM aurea_delivery_rpc.active_recipients r WHERE r.organization_id=p_org AND r.active AND r.email=addr AND p_id=md5(c::text||'':''||r.id::text)::uuid) THEN RETURN ''invalid''; END IF;')
 ) AS x(sig,before_text,after_text) LOOP
 d:=pg_get_functiondef(to_regprocedure(p));
 n:=(length(d)-length(replace(d,s,'')))/length(s);
 IF n<>1 THEN RAISE EXCEPTION 'Patch anchor mismatch % (% occurrences)',p,n; END IF;
 EXECUTE replace(d,s,t);
 END LOOP;
END $patch$;
-- Educational access adapter. Existing private admin schema already has authenticated USAGE, no new schema/table grants.
-- Only returns a boolean, never names, roster counts, employee responses or other companies' data.
CREATE FUNCTION aurea_admin.education_entitled_v1(p_org uuid) RETURNS boolean
 LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path='' AS $function$
DECLARE u uuid:=auth.uid(); addr text; is_manager boolean; is_employee boolean;
BEGIN
 IF u IS NULL OR p_org IS NULL THEN RETURN false; END IF;
 SELECT lower(btrim(a.email)) INTO addr FROM auth.users a JOIN auth.sessions s ON s.user_id=a.id
 WHERE a.id=u AND s.id::text=auth.jwt()->>'session_id' AND (s.not_after IS NULL OR s.not_after>clock_timestamp())
 AND NOT a.is_anonymous AND a.deleted_at IS NULL AND a.email_confirmed_at IS NOT NULL AND a.email IS NOT NULL
 AND (a.banned_until IS NULL OR a.banned_until<=clock_timestamp());
 IF NOT FOUND OR addr IS NULL OR addr='' THEN RETURN false; END IF;
 -- Dedicated operator/service identities do not gain access merely by their operational role.
 is_manager:=EXISTS(SELECT 1 FROM aurea_private.memberships m WHERE m.organization_id=p_org AND m.user_id=u AND m.role IN ('owner','manager'));
 is_employee:=EXISTS(SELECT 1 FROM aurea_delivery_rpc.active_recipients r WHERE r.organization_id=p_org AND r.active AND r.email=addr);
 IF NOT is_manager AND NOT is_employee THEN RETURN false; END IF;
 -- Fail closed if the production activation gate is absent (including current staging).
 IF to_regprocedure('aurea_admin.require_activation_v1(text)') IS NULL THEN RETURN false; END IF;
 PERFORM aurea_admin.require_activation_v1(CASE WHEN is_manager THEN 'manager' ELSE 'employee' END);
 RETURN EXISTS(SELECT 1 FROM aurea_commercial.accounts a WHERE a.organization_id=p_org
   AND aurea_commercial.status(a.organization_id) IN ('trial','active','complimentary')
   AND aurea_commercial.licensed_count_v1(a.organization_id)<=a.seats);
END $function$;
REVOKE ALL ON FUNCTION aurea_admin.education_entitled_v1(uuid) FROM PUBLIC,anon,authenticated,service_role;
GRANT EXECUTE ON FUNCTION aurea_admin.education_entitled_v1(uuid) TO authenticated;
CREATE FUNCTION public.aurea_education_access_v1(p_org uuid) RETURNS boolean
 LANGUAGE sql STABLE SECURITY INVOKER SET search_path='' AS $function$
 SELECT aurea_admin.education_entitled_v1(p_org)
$function$;
REVOKE ALL ON FUNCTION public.aurea_education_access_v1(uuid) FROM PUBLIC,anon,authenticated,service_role;
GRANT EXECUTE ON FUNCTION public.aurea_education_access_v1(uuid) TO authenticated;
-- Active commercial entitlement for existing manager paths; no new client grants.
CREATE FUNCTION aurea_commercial.account_entitled_v1(p_org uuid) RETURNS boolean
 LANGUAGE sql STABLE SECURITY INVOKER SET search_path='' AS $function$
 SELECT coalesce((SELECT aurea_commercial.status(a.organization_id) IN ('trial','active','complimentary') AND aurea_commercial.licensed_count_v1(a.organization_id)<=a.seats FROM aurea_commercial.accounts a WHERE a.organization_id=p_org),false)
$function$;
REVOKE ALL ON FUNCTION aurea_commercial.account_entitled_v1(uuid) FROM PUBLIC,anon,authenticated,service_role;
-- Reviewed commercial enforcement: existing definer functions retain owners, grants, original membership/validation and rate checks.
DO $access_patch$
DECLARE f record; d text; n integer; proc_oid regprocedure;
BEGIN
 FOR f IN SELECT * FROM (VALUES
 ('aurea_manager_rpc.aurea_manager_actions(uuid)','6f7070cf87cb7a72e9db356fd4c01316','0d44262b64155c21f4d45a251f3e76c7',' perform aurea_manager_rpc.check_session_and_limit();',' perform aurea_manager_rpc.check_session_and_limit();
 IF NOT EXISTS(SELECT 1 FROM aurea_private.memberships m WHERE m.user_id=auth.uid() AND m.organization_id=p_organization_id AND m.role IN (''owner'',''manager'')) OR NOT aurea_commercial.account_entitled_v1(p_organization_id) THEN RAISE EXCEPTION ''Access denied'' USING ERRCODE=''42501''; END IF;'),
 ('aurea_manager_rpc.aurea_manager_cycles(uuid)','c593b53a9907ddab862eb6b040e302ce','27a7ab7aa762b9ad139b928db9b01701',' perform aurea_manager_rpc.check_session_and_limit();',' perform aurea_manager_rpc.check_session_and_limit();
 IF NOT EXISTS(SELECT 1 FROM aurea_private.memberships m WHERE m.user_id=auth.uid() AND m.organization_id=p_organization_id AND m.role IN (''owner'',''manager'')) OR NOT aurea_commercial.account_entitled_v1(p_organization_id) THEN RAISE EXCEPTION ''Access denied'' USING ERRCODE=''42501''; END IF;'),
 ('aurea_manager_rpc.aurea_manager_save_action(uuid,text,date,uuid,uuid,text)','340a69dc6ad1b77bd95e32b609e9ada6','d223014b0b7af5eccc56324d3521a1b7',' perform aurea_manager_rpc.check_session_and_limit();',' perform aurea_manager_rpc.check_session_and_limit();
 IF NOT EXISTS(SELECT 1 FROM aurea_private.memberships m WHERE m.user_id=auth.uid() AND m.organization_id=p_organization_id AND m.role IN (''owner'',''manager'')) OR NOT aurea_commercial.account_entitled_v1(p_organization_id) THEN RAISE EXCEPTION ''Access denied'' USING ERRCODE=''42501''; END IF;'),
 ('aurea_manager_rpc.aurea_manager_summary(uuid)','7ee2afd7dfd886370ae0bf792822d760','0a633dd0e5afa99a22313926bb993940',' perform aurea_manager_rpc.check_session_and_limit();',' perform aurea_manager_rpc.check_session_and_limit();
 IF NOT EXISTS(SELECT 1 FROM aurea_private.memberships m WHERE m.user_id=auth.uid() AND m.organization_id=p_organization_id AND m.role IN (''owner'',''manager'')) OR NOT aurea_commercial.account_entitled_v1(p_organization_id) THEN RAISE EXCEPTION ''Access denied'' USING ERRCODE=''42501''; END IF;'),
 ('aurea_private.manager_publications_v2(uuid)','38deef5c58904825812f8f8a5266e117','384136dcf00b61f89dd5b46cee62ba2e',' perform aurea_manager_rpc.check_session_and_limit();',' perform aurea_manager_rpc.check_session_and_limit();
 IF NOT EXISTS(SELECT 1 FROM aurea_private.memberships m WHERE m.user_id=auth.uid() AND m.organization_id=p_org AND m.role IN (''owner'',''manager'')) OR NOT aurea_commercial.account_entitled_v1(p_org) THEN RAISE EXCEPTION ''Access denied'' USING ERRCODE=''42501''; END IF;'),
 ('public.aurea_employee_invitation(text)','b1e0414897c03f7a31ff03398e4bc3c4','e0d070ea42d4a5943aef09d98127fdd6',' return jsonb_build_object(''status'',''unavailable'');end if;
 select jsonb_agg(',' return jsonb_build_object(''status'',''unavailable'');end if;
 IF NOT EXISTS(SELECT 1 FROM aurea_private.invitations i JOIN aurea_private.cycles c ON c.id=i.cycle_id JOIN aurea_delivery_rpc.active_recipients r ON r.organization_id=c.organization_id AND r.active AND r.email=lower(btrim(i.recipient_address)) WHERE i.id=v_inv.id AND aurea_commercial.pulse_eligible_v1(c.organization_id)) THEN RETURN jsonb_build_object(''status'',''unavailable''); END IF;
 select jsonb_agg('),
 ('public.aurea_employee_submit(text,jsonb)','bd1dd89b3b7e23c496a8726d3506c586','75ec8aa190bdd01b14cdcf30d13c87e6',' return jsonb_build_object(''status'',''unavailable'');end if;
 select count(*) into v_count',' return jsonb_build_object(''status'',''unavailable'');end if;
 IF NOT EXISTS(SELECT 1 FROM aurea_private.invitations i JOIN aurea_private.cycles c ON c.id=i.cycle_id JOIN aurea_delivery_rpc.active_recipients r ON r.organization_id=c.organization_id AND r.active AND r.email=lower(btrim(i.recipient_address)) WHERE i.id=v_inv.id AND aurea_commercial.pulse_eligible_v1(c.organization_id)) THEN RETURN jsonb_build_object(''status'',''unavailable''); END IF;
 select count(*) into v_count')
 ) x(sig,before_hash,after_hash,before_text,after_text) LOOP
 proc_oid:=to_regprocedure(f.sig);
 IF proc_oid IS NULL OR NOT EXISTS(SELECT 1 FROM pg_proc WHERE oid=proc_oid AND pg_get_userbyid(proowner)='postgres') THEN RAISE EXCEPTION 'Access function missing or owner changed: %',f.sig; END IF;
 d:=pg_get_functiondef(proc_oid);
 IF md5(d) IS DISTINCT FROM f.before_hash THEN RAISE EXCEPTION 'Access definition changed: %',f.sig; END IF;
 n:=(length(d)-length(replace(d,f.before_text,'')))/length(f.before_text);
 IF n<>1 THEN RAISE EXCEPTION 'Access patch anchor mismatch: %',f.sig; END IF;
 EXECUTE replace(d,f.before_text,f.after_text);
 IF md5(pg_get_functiondef(proc_oid)) IS DISTINCT FROM f.after_hash THEN RAISE EXCEPTION 'Access postflight hash mismatch: %',f.sig; END IF;
 END LOOP;
END $access_patch$;
-- Original privacy function and all existing response/history tables are untouched.
DO $postflight$ BEGIN
 IF md5(pg_get_functiondef('aurea_private.privacy_publishable_v1(bigint,bigint,bigint)'::regprocedure))<>'6707b20337b83c3db4af9433fb042d88' THEN RAISE EXCEPTION 'Privacy drift'; END IF;
 IF has_schema_privilege('authenticated','aurea_commercial','USAGE') OR has_function_privilege('anon','public.aurea_education_access_v1(uuid)','EXECUTE') THEN RAISE EXCEPTION 'Grant drift'; END IF;
END $postflight$;
COMMIT;
