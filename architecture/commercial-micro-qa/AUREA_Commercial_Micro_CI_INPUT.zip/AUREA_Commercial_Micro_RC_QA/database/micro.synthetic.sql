-- QA ONLY after approved installation in a disposable PG17 or approved staging transaction.
-- No provider, real account or mail. DO NOT execute on production. No persistent test rows.
BEGIN;
SET LOCAL statement_timeout='60s';
DO $test$
DECLARE n int; org uuid; i uuid; got bigint; before_paid timestamptz; p text; blocked boolean; actual_plan text; gift uuid; second_org uuid;
BEGIN
 FOREACH n IN ARRAY ARRAY[1,2,4,5,10,12,13,15,16,25,26,60,61,150,100000] LOOP
  FOREACH p IN ARRAY ARRAY['monthly','annual'] LOOP
   org:=gen_random_uuid();
   INSERT INTO aurea_private.organizations(id,name) VALUES(org,'SYNTHETIC MICRO QA '||org);
   INSERT INTO aurea_commercial.accounts(organization_id,seats,renewal_plan,renewal_enabled,paid_until) VALUES(org,n,p,true,now()-interval '1 day');
   SELECT amount_cents,plan INTO got,actual_plan FROM aurea_commercial.renewal_quote(org,now());
   IF got IS DISTINCT FROM n::bigint*(CASE WHEN p='annual' THEN 3000 ELSE 300 END) OR actual_plan IS DISTINCT FROM p THEN RAISE EXCEPTION 'Quote mismatch %, %',n,p; END IF;
   i:=aurea_billing.issue(org,p,'EUR',1,current_date,'bank');
   IF (SELECT amount_cents FROM aurea_commercial.invoices WHERE id=i) IS DISTINCT FROM got OR (SELECT amount_minor FROM aurea_billing.orders WHERE invoice_id=i) IS DISTINCT FROM got THEN RAISE EXCEPTION 'Invoice/order mismatch %, %',n,p; END IF;
   IF EXISTS(SELECT 1 FROM aurea_commercial.renewal_quote(org,now())) THEN RAISE EXCEPTION 'Duplicate quote with open invoice'; END IF;
   IF n=1 THEN
    blocked:=false;BEGIN PERFORM aurea_billing.issue(org,p,'EUR',1,current_date,'bank');EXCEPTION WHEN unique_violation THEN blocked:=true;END;
    IF NOT blocked THEN RAISE EXCEPTION 'Duplicate invoice not rejected'; END IF;
    PERFORM aurea_commercial.confirm_payment(org,i,'micro-qa-'||i,got,'EUR');
    SELECT paid_until INTO before_paid FROM aurea_commercial.accounts WHERE organization_id=org;
    blocked:=false;BEGIN PERFORM aurea_commercial.confirm_payment(org,i,'micro-qa-'||i,got,'EUR');EXCEPTION WHEN raise_exception OR unique_violation THEN blocked:=true;END;
    IF NOT blocked OR (SELECT paid_until FROM aurea_commercial.accounts WHERE organization_id=org) IS DISTINCT FROM before_paid THEN RAISE EXCEPTION 'Duplicate payment changed term'; END IF;
   END IF;
  END LOOP;
 END LOOP;
 -- Roster hard count, automatic eligibility by actual respondents, no survey for a one-seat gift.
 org:=gen_random_uuid(); INSERT INTO aurea_private.organizations(id,name) VALUES(org,'SYNTHETIC MICRO CAPACITY '||org);
 INSERT INTO aurea_commercial.accounts(organization_id,seats) VALUES(org,1);
 INSERT INTO aurea_delivery_rpc.active_recipients(organization_id,email) VALUES(org,'qa-one@example.invalid');
 IF aurea_commercial.pulse_eligible_v1(org) THEN RAISE EXCEPTION 'One seat permitted pulse'; END IF;
 blocked:=false;BEGIN INSERT INTO aurea_delivery_rpc.active_recipients(organization_id,email) VALUES(org,'qa-two@example.invalid');EXCEPTION WHEN check_violation THEN blocked:=true;END;
 IF NOT blocked THEN RAISE EXCEPTION 'Second recipient exceeds cap'; END IF;
 UPDATE aurea_commercial.accounts SET seats=5 WHERE organization_id=org;
 INSERT INTO aurea_delivery_rpc.active_recipients(organization_id,email) SELECT org,'qa-'||g||'@example.invalid' FROM generate_series(2,5) g;
 IF NOT aurea_commercial.pulse_eligible_v1(org) THEN RAISE EXCEPTION 'Five active recipients not eligible'; END IF;
 blocked:=false;BEGIN UPDATE aurea_commercial.accounts SET seats=4 WHERE organization_id=org;EXCEPTION WHEN check_violation THEN blocked:=true;END;
 IF NOT blocked THEN RAISE EXCEPTION 'Unsafe decrease accepted'; END IF;
 UPDATE aurea_delivery_rpc.active_recipients SET active=false WHERE organization_id=org AND email='qa-5@example.invalid';
 UPDATE aurea_commercial.accounts SET seats=4 WHERE organization_id=org;
 IF aurea_commercial.pulse_eligible_v1(org) THEN RAISE EXCEPTION 'Downgrade still eligible'; END IF;
 UPDATE aurea_commercial.accounts SET seats=5,suspended=true WHERE organization_id=org;
 UPDATE aurea_delivery_rpc.active_recipients SET active=true WHERE organization_id=org AND email='qa-5@example.invalid';
 IF aurea_commercial.pulse_eligible_v1(org) THEN RAISE EXCEPTION 'Suspended account eligible'; END IF;
 gift:=gen_random_uuid(); INSERT INTO aurea_private.organizations(id,name) VALUES(gift,'SYNTHETIC GIFT '||gift);
 INSERT INTO aurea_commercial.accounts(organization_id,seats) VALUES(gift,12); PERFORM aurea_commercial.grant_complimentary(gift);
 IF aurea_commercial.status(gift)<>'complimentary' OR EXISTS(SELECT 1 FROM aurea_commercial.renewal_quote(gift,now()+interval '1 year')) THEN RAISE EXCEPTION 'Gift entitlement failed'; END IF;
 blocked:=false;BEGIN PERFORM aurea_billing.issue(gift,'monthly','EUR',1,current_date,'bank');EXCEPTION WHEN raise_exception THEN blocked:=true;END;
 IF NOT blocked THEN RAISE EXCEPTION 'Gift billed'; END IF;
 IF aurea_private.privacy_publishable_v1(4,2,4) OR NOT aurea_private.privacy_publishable_v1(5,2,5) OR aurea_private.privacy_publishable_v1(5,4,5) OR aurea_private.privacy_publishable_v1(5,5,5) OR aurea_private.privacy_publishable_v1(6,3,5) THEN RAISE EXCEPTION 'Privacy predicate changed'; END IF;
 IF has_function_privilege('anon','public.aurea_education_access_v1(uuid)','EXECUTE') OR has_schema_privilege('authenticated','aurea_commercial','USAGE') THEN RAISE EXCEPTION 'Unauthorized grant'; END IF;
 IF aurea_admin.education_entitled_v1(gift) THEN RAISE EXCEPTION 'No session yet education allowed'; END IF;
 RAISE NOTICE 'PASS targeted SQL assertions (rollback transaction follows)';
END $test$;
ROLLBACK;
