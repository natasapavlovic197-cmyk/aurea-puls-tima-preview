-- REVIEW ONLY. Revert BEFORE any real account, invoice, roster, scope or delivery exists.
-- After launch, stop activation and prepare forward reconciliation; never reprice historic invoices.
BEGIN;
SET LOCAL lock_timeout='5s';
LOCK TABLE aurea_commercial.accounts,aurea_commercial.invoices,aurea_commercial.payments,aurea_billing.orders,
 aurea_delivery_rpc.active_recipients,aurea_delivery_rpc.scopes,aurea_private.memberships,aurea_private.weekly_delivery_jobs IN ACCESS EXCLUSIVE MODE;
DO $guard$ BEGIN
 IF EXISTS(SELECT 1 FROM aurea_commercial.accounts) OR EXISTS(SELECT 1 FROM aurea_commercial.invoices) OR EXISTS(SELECT 1 FROM aurea_commercial.payments)
 OR EXISTS(SELECT 1 FROM aurea_billing.orders) OR EXISTS(SELECT 1 FROM aurea_delivery_rpc.active_recipients) OR EXISTS(SELECT 1 FROM aurea_delivery_rpc.scopes)
 OR EXISTS(SELECT 1 FROM aurea_private.weekly_delivery_jobs) THEN RAISE EXCEPTION 'Rollback prohibited: reconcile real records'; END IF;
 IF to_regclass('aurea_admin.activation_gates_v1') IS NOT NULL THEN
  IF EXISTS(SELECT 1 FROM aurea_admin.activation_gates_v1 WHERE enabled) THEN RAISE EXCEPTION 'Disable activation first'; END IF;
 END IF;
END $guard$;
-- Reviewed commercial enforcement: existing definer functions retain owners, grants, original membership/validation and rate checks.
DO $access_restore$
DECLARE f record; d text; n integer; proc_oid regprocedure;
BEGIN
 FOR f IN SELECT * FROM (VALUES
 ('aurea_manager_rpc.aurea_manager_actions(uuid)','0d44262b64155c21f4d45a251f3e76c7','6f7070cf87cb7a72e9db356fd4c01316',' perform aurea_manager_rpc.check_session_and_limit();
 IF NOT EXISTS(SELECT 1 FROM aurea_private.memberships m WHERE m.user_id=auth.uid() AND m.organization_id=p_organization_id AND m.role IN (''owner'',''manager'')) OR NOT aurea_commercial.account_entitled_v1(p_organization_id) THEN RAISE EXCEPTION ''Access denied'' USING ERRCODE=''42501''; END IF;',' perform aurea_manager_rpc.check_session_and_limit();'),
 ('aurea_manager_rpc.aurea_manager_cycles(uuid)','27a7ab7aa762b9ad139b928db9b01701','c593b53a9907ddab862eb6b040e302ce',' perform aurea_manager_rpc.check_session_and_limit();
 IF NOT EXISTS(SELECT 1 FROM aurea_private.memberships m WHERE m.user_id=auth.uid() AND m.organization_id=p_organization_id AND m.role IN (''owner'',''manager'')) OR NOT aurea_commercial.account_entitled_v1(p_organization_id) THEN RAISE EXCEPTION ''Access denied'' USING ERRCODE=''42501''; END IF;',' perform aurea_manager_rpc.check_session_and_limit();'),
 ('aurea_manager_rpc.aurea_manager_save_action(uuid,text,date,uuid,uuid,text)','d223014b0b7af5eccc56324d3521a1b7','340a69dc6ad1b77bd95e32b609e9ada6',' perform aurea_manager_rpc.check_session_and_limit();
 IF NOT EXISTS(SELECT 1 FROM aurea_private.memberships m WHERE m.user_id=auth.uid() AND m.organization_id=p_organization_id AND m.role IN (''owner'',''manager'')) OR NOT aurea_commercial.account_entitled_v1(p_organization_id) THEN RAISE EXCEPTION ''Access denied'' USING ERRCODE=''42501''; END IF;',' perform aurea_manager_rpc.check_session_and_limit();'),
 ('aurea_manager_rpc.aurea_manager_summary(uuid)','0a633dd0e5afa99a22313926bb993940','7ee2afd7dfd886370ae0bf792822d760',' perform aurea_manager_rpc.check_session_and_limit();
 IF NOT EXISTS(SELECT 1 FROM aurea_private.memberships m WHERE m.user_id=auth.uid() AND m.organization_id=p_organization_id AND m.role IN (''owner'',''manager'')) OR NOT aurea_commercial.account_entitled_v1(p_organization_id) THEN RAISE EXCEPTION ''Access denied'' USING ERRCODE=''42501''; END IF;',' perform aurea_manager_rpc.check_session_and_limit();'),
 ('aurea_private.manager_publications_v2(uuid)','384136dcf00b61f89dd5b46cee62ba2e','38deef5c58904825812f8f8a5266e117',' perform aurea_manager_rpc.check_session_and_limit();
 IF NOT EXISTS(SELECT 1 FROM aurea_private.memberships m WHERE m.user_id=auth.uid() AND m.organization_id=p_org AND m.role IN (''owner'',''manager'')) OR NOT aurea_commercial.account_entitled_v1(p_org) THEN RAISE EXCEPTION ''Access denied'' USING ERRCODE=''42501''; END IF;',' perform aurea_manager_rpc.check_session_and_limit();'),
 ('public.aurea_employee_invitation(text)','e0d070ea42d4a5943aef09d98127fdd6','b1e0414897c03f7a31ff03398e4bc3c4',' return jsonb_build_object(''status'',''unavailable'');end if;
 IF NOT EXISTS(SELECT 1 FROM aurea_private.invitations i JOIN aurea_private.cycles c ON c.id=i.cycle_id JOIN aurea_delivery_rpc.active_recipients r ON r.organization_id=c.organization_id AND r.active AND r.email=lower(btrim(i.recipient_address)) WHERE i.id=v_inv.id AND aurea_commercial.pulse_eligible_v1(c.organization_id)) THEN RETURN jsonb_build_object(''status'',''unavailable''); END IF;
 select jsonb_agg(',' return jsonb_build_object(''status'',''unavailable'');end if;
 select jsonb_agg('),
 ('public.aurea_employee_submit(text,jsonb)','75ec8aa190bdd01b14cdcf30d13c87e6','bd1dd89b3b7e23c496a8726d3506c586',' return jsonb_build_object(''status'',''unavailable'');end if;
 IF NOT EXISTS(SELECT 1 FROM aurea_private.invitations i JOIN aurea_private.cycles c ON c.id=i.cycle_id JOIN aurea_delivery_rpc.active_recipients r ON r.organization_id=c.organization_id AND r.active AND r.email=lower(btrim(i.recipient_address)) WHERE i.id=v_inv.id AND aurea_commercial.pulse_eligible_v1(c.organization_id)) THEN RETURN jsonb_build_object(''status'',''unavailable''); END IF;
 select count(*) into v_count',' return jsonb_build_object(''status'',''unavailable'');end if;
 select count(*) into v_count')
 ) x(sig,before_hash,after_hash,before_text,after_text) LOOP
 proc_oid:=to_regprocedure(f.sig);
 IF proc_oid IS NULL OR NOT EXISTS(SELECT 1 FROM pg_proc WHERE oid=proc_oid AND pg_get_userbyid(proowner)='postgres') THEN RAISE EXCEPTION 'Access function missing or owner changed: %',f.sig; END IF;
 d:=pg_get_functiondef(proc_oid);
 IF md5(d) IS DISTINCT FROM f.before_hash THEN RAISE EXCEPTION 'Access definition changed: %',f.sig; END IF;
 n:=(length(d)-length(replace(d,f.before_text,'')))/length(f.before_text);
 IF n<>1 THEN RAISE EXCEPTION 'Access patch anchor mismatch: %',f.sig; END IF;
 EXECUTE replace(d,f.before_text,f.after_text);
 IF md5(pg_get_functiondef(proc_oid)) IS DISTINCT FROM f.after_hash THEN RAISE EXCEPTION 'Access postflight hash mismatch: %',f.sig; END IF;
 END LOOP;
END $access_restore$;
DROP FUNCTION aurea_commercial.account_entitled_v1(uuid);
DROP FUNCTION public.aurea_education_access_v1(uuid);
DROP FUNCTION aurea_admin.education_entitled_v1(uuid);
DO $restore$
DECLARE p text; d text; s text; t text; n integer; fn record; h text;
BEGIN
 FOR p,s,t IN SELECT * FROM (VALUES
 ('aurea_delivery_rpc.impl_issue_hmac_invitation(uuid,date,uuid,text,text,timestamptz)', 'if not found then return ''unavailable''; end if; IF NOT EXISTS(SELECT 1 FROM aurea_delivery_rpc.active_recipients r WHERE r.organization_id=p_org AND r.active AND r.email=addr AND p_id=md5(c::text||'':''||r.id::text)::uuid) THEN RETURN ''invalid''; END IF;', 'if not found then return ''unavailable''; end if;'),
 ('aurea_delivery_rpc.schedule_at(timestamptz)', 'c.state=''open'' AND EXISTS(SELECT 1 FROM aurea_delivery_rpc.scopes s WHERE s.user_id=auth.uid() AND s.organization_id=c.organization_id);', 'c.state=''open'' AND aurea_delivery_rpc.allowed_org(c.organization_id);'),
 ('aurea_delivery_rpc.schedule_at(timestamptz)', 'WHERE s.user_id=auth.uid() AND aurea_delivery_rpc.allowed_org(s.organization_id) AND NOT EXISTS', 'WHERE s.user_id=auth.uid() AND NOT EXISTS'),
 ('aurea_delivery_rpc.prepare_monday(timestamptz)', 'WHERE s.user_id=auth.uid() AND aurea_delivery_rpc.allowed_org(s.organization_id) ORDER BY s.organization_id LOOP', 'WHERE s.user_id=auth.uid() ORDER BY s.organization_id LOOP'),
 ('aurea_delivery_rpc.allowed_org(uuid)', 's.organization_id=p_org) AND aurea_commercial.pulse_eligible_v1(p_org)', 's.organization_id=p_org)')
 ) AS x(sig,before_text,after_text) LOOP
 d:=pg_get_functiondef(to_regprocedure(p)); n:=(length(d)-length(replace(d,s,'')))/length(s);
 IF n<>1 THEN RAISE EXCEPTION 'Rollback anchor mismatch %',p; END IF;
 EXECUTE replace(d,s,t);
 END LOOP;
 FOR fn IN SELECT * FROM (VALUES
 ('aurea_delivery_rpc.allowed_org(uuid)','3df99326df7cd2380bc079ea23d18c11','3df99326df7cd2380bc079ea23d18c11'),
 ('aurea_delivery_rpc.prepare_monday(timestamptz)','854bdfcfce474bcaab5a350c925af903','7793741fa6750a928b0fdbceac7a75c6'),
 ('aurea_delivery_rpc.schedule_at(timestamptz)','699f617eac38fac403ab76f54901a77e','d69a2906ae682646872d8c0207adb2ab'),
 ('aurea_delivery_rpc.impl_issue_hmac_invitation(uuid,date,uuid,text,text,timestamptz)','207994bab4ca27d6aad229e867dcf2c9','207994bab4ca27d6aad229e867dcf2c9')
 ) x(sig,stage_hash,prod_hash) LOOP
 SELECT md5(pg_get_functiondef(to_regprocedure(fn.sig))) INTO h;
 IF h IS DISTINCT FROM CASE WHEN to_regclass('aurea_admin.activation_gates_v1') IS NULL THEN fn.stage_hash ELSE fn.prod_hash END THEN RAISE EXCEPTION 'Rollback differs from reviewed baseline: %',fn.sig; END IF;
 END LOOP;
END $restore$;
DROP TRIGGER micro_roster_capacity_v1 ON aurea_delivery_rpc.active_recipients;
DROP TRIGGER micro_membership_capacity_v1 ON aurea_private.memberships;
DROP TRIGGER micro_account_insert_capacity_v1 ON aurea_commercial.accounts;
DROP TRIGGER micro_account_update_capacity_v1 ON aurea_commercial.accounts;
DROP FUNCTION aurea_commercial.guard_roster_capacity_v1();
DROP FUNCTION aurea_commercial.guard_seat_capacity_v1();
DROP FUNCTION aurea_commercial.pulse_eligible_v1(uuid);
DROP FUNCTION aurea_commercial.licensed_count_v1(uuid);
ALTER TABLE aurea_commercial.invoices ALTER COLUMN amount_cents SET EXPRESSION AS
 (CASE WHEN plan='annual' THEN greatest(3900::bigint,seats::bigint*250)*12 ELSE greatest(3900::bigint,seats::bigint*300) END);
CREATE OR REPLACE FUNCTION aurea_commercial.renewal_quote(p_org uuid, p_at timestamp with time zone DEFAULT now())
 RETURNS TABLE(organization_id uuid, plan text, seats integer, amount_cents bigint, currency text, charge_performed boolean)
 LANGUAGE sql STABLE SET search_path TO '' AS $function$
 SELECT a.organization_id,a.renewal_plan,a.seats,
 CASE WHEN a.renewal_plan='annual' THEN greatest(3900::bigint,a.seats::bigint*250)*12 ELSE greatest(3900::bigint,a.seats::bigint*300) END,
 'EUR'::text,false
 FROM aurea_commercial.accounts a
 WHERE a.organization_id=p_org AND a.renewal_enabled AND NOT a.complimentary AND NOT a.suspended
 AND a.paid_until IS NOT NULL AND a.paid_until<=p_at
 AND NOT EXISTS(SELECT 1 FROM aurea_commercial.invoices i WHERE i.organization_id=a.organization_id AND i.paid_at IS NULL AND i.cancelled_at IS NULL)
$function$;
-- Body whitespace is deliberately identical to the inspected definition (hash checked).
DO $check$ BEGIN
 IF md5(pg_get_functiondef('aurea_commercial.renewal_quote(uuid,timestamptz)'::regprocedure))<>'148ae557be3e8f6a4dcbe0dd67a3ca12' THEN RAISE EXCEPTION 'Renewal baseline mismatch'; END IF;
 IF md5(pg_get_functiondef('aurea_private.privacy_publishable_v1(bigint,bigint,bigint)'::regprocedure))<>'6707b20337b83c3db4af9433fb042d88' THEN RAISE EXCEPTION 'Privacy drift'; END IF;
END $check$;
COMMIT;
