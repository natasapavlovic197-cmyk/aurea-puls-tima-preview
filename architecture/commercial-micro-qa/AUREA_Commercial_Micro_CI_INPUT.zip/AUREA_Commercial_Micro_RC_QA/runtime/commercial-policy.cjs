'use strict';
// EUR cents, not a payment request. Keep invoice / renewal formulas in parity.
function price(seats,plan){
 if(!Number.isSafeInteger(seats)||seats<1||seats>100000||!['monthly','annual','gift'].includes(plan))throw Error('Invalid quote');
 return plan==='gift'?0:seats*(plan==='annual'?3000:300);
}
function capabilities({seats,licensed,respondents,status}){
 const valid=Number.isSafeInteger(seats)&&seats>=1&&seats<=100000&&Number.isSafeInteger(licensed)&&licensed>=0&&licensed<=seats&&Number.isSafeInteger(respondents)&&respondents>=0&&respondents<=licensed;
 const education=valid&&['active','trial','complimentary'].includes(status);
 return Object.freeze({education,pulse:education&&respondents>=5});
}
function profitability({seats,plan,handlingMinutes,handlingHourly,bankFee,perSeatMonth,fixedMonth,companies}){
 const period=plan==='annual'?12:1;
 if(![handlingMinutes,handlingHourly,bankFee,perSeatMonth,fixedMonth,companies].every(x=>Number.isFinite(x)&&x>=0)||companies<1||plan==='gift')throw Error('Invalid assumptions');
 const revenue=price(seats,plan)/100, direct=handlingMinutes*handlingHourly/60+bankFee+seats*perSeatMonth*period;
 return {revenue,direct,contribution:revenue-direct,allocatedFixed:fixedMonth*period/companies,netBeforeTax:revenue-direct-fixedMonth*period/companies};
}
module.exports={price,capabilities,profitability};
