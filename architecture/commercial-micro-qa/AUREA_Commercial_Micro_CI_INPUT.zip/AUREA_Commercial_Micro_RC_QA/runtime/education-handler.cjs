'use strict';
// Candidate only. Wire to the existing protected runtime after explicit approval.
// Uses the caller's Auth token, no privileged keys. The existing locked educational
// document must be supplied from architecture/signature22-education.cjs at build time.
const UUID=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
function createEducationHandler({url,publishableKey,origin,document,fetchImpl=globalThis.fetch,enabled=false}){
 if(!['https://ublzmoroanhlcgpnxilw.supabase.co','https://dlibifwlmbfkboerlmqd.supabase.co'].includes(url)||typeof publishableKey!=='string'||!publishableKey.startsWith('sb_publishable_')||typeof document!=='string'||!document.includes('signatureEducationGuard')||!document.includes('signatureEducationIsolation')||typeof origin!=='string'||!/^https:\/\/[^/]+$/.test(origin))throw Error('Invalid education config');
 const security={'cache-control':'no-store, private','referrer-policy':'no-referrer','x-content-type-options':'nosniff','x-robots-tag':'noindex, nofollow','vary':'Origin'};
 const reply=(status,body='',extra={})=>new Response(body,{status,headers:{...security,...extra}});
 return async request=>{
  if(!enabled||request.headers.get('origin')!==origin||request.method!=='POST')return reply(403);
  const authorization=request.headers.get('authorization')||'';
  if(authorization.length>8192||!/^Bearer [A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(authorization))return reply(401);
  if(!/^application\/json(?:;|$)/i.test(request.headers.get('content-type')||''))return reply(415);
  const len=Number(request.headers.get('content-length')||0);if(len>1024)return reply(413);
  let payload;try{const reader=request.body?.getReader();if(!reader)return reply(400);const decoder=new TextDecoder('utf-8',{fatal:true});let size=0,body='';while(true){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>1024){await reader.cancel();return reply(413);}body+=decoder.decode(value,{stream:true});}body+=decoder.decode();payload=JSON.parse(body);}catch{return reply(400);}
  if(!payload||Array.isArray(payload)||Object.keys(payload).length!==1||typeof payload.organizationId!=='string'||!UUID.test(payload.organizationId))return reply(400);
  try{
   const result=await fetchImpl(url+'/rest/v1/rpc/aurea_education_access_v1',{method:'POST',headers:{apikey:publishableKey,authorization,'content-type':'application/json'},body:JSON.stringify({p_org:payload.organizationId}),cache:'no-store',redirect:'error',signal:AbortSignal.timeout(8000)});
   if(!result.ok||await result.json()!==true)return reply(403);
   return reply(200,document,{'content-type':'text/html; charset=utf-8','content-security-policy':"default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; font-src data:; connect-src 'none'; form-action 'none'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'"});
  }catch{return reply(403);}
 };
}
module.exports={createEducationHandler};
