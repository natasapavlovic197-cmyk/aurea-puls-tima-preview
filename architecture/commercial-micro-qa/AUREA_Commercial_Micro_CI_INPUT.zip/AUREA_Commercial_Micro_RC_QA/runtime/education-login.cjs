'use strict';
const {createClient}=require('@supabase/supabase-js');
const {mountEducation}=require('./education-client.cjs');
const $=id=>document.getElementById(id),status=s=>{$('status').textContent=s;};
let client=null,dispose=null,busy=false,epoch=0;
const config=globalThis.AUREA_PRODUCTION_CONFIG;
const safe=config?.environment==='production'&&config.enabled===false&&config.url==='https://dlibifwlmbfkboerlmqd.supabase.co'&&typeof config.key==='string'&&config.key.startsWith('sb_publishable_')&&(config.manager===true||config.employee===true);
function invalidate(){epoch++;if(dispose){dispose();dispose=null;} $('workspace').hidden=true;$('login').hidden=false;$('password').value='';}
async function close(){invalidate();if(client){const result=await client.auth.signOut({scope:'local'});if(result?.error)throw Error('Server sign-out unconfirmed');}}
if(!safe){status('Produkcijski pristup još nije aktiviran.');$('submit').disabled=true;}
else{
 client=createClient(config.url,config.key,{auth:{persistSession:false,autoRefreshToken:true,detectSessionInUrl:false}});
 client.auth.onAuthStateChange((event)=>{if(event==='SIGNED_OUT'){invalidate();status('Odjavljeni ste.');}});
 $('login').addEventListener('submit',async e=>{e.preventDefault();if(busy)return;busy=true;const attempt=++epoch;$('submit').disabled=true;try{const pw=$('password').value;$('password').value='';const org=$('org').value.trim();if(!/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(org))throw Error('Invalid company');const {data,error}=await client.auth.signInWithPassword({email:$('email').value.trim(),password:pw});if(error||!data.session?.access_token||attempt!==epoch)throw Error('Sign-in denied');const cleanup=await mountEducation({root:$('content'),organizationId:org,accessToken:data.session.access_token,isCurrent:()=>attempt===epoch});if(attempt!==epoch){cleanup();throw Error('Session ended');}dispose=cleanup;$('login').hidden=true;$('workspace').hidden=false;status('Pristup edukativnim sadržajima je potvrđen.');}catch{try{await close();}catch{}status('Pristup nije potvrđen. Proverite podatke sa administratorom.');}finally{busy=false;$('submit').disabled=false;}});
 $('logout').addEventListener('click',async()=>{if(busy)return;busy=true;try{await close();status('Odjavljeni ste.');}catch{status('Lokalni pristup zatvoren; odjava na serveru nije potvrđena.');}finally{busy=false;}});
}
