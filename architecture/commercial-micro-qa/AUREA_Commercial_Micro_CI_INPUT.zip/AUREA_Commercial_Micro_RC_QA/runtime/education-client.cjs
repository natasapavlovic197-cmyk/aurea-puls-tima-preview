'use strict';
// No pulse invitation required. Auth sign-in is handled by the approved host app.
// The token is never put into a URL, local storage, or inside the simulation document.
async function mountEducation({root,organizationId,accessToken,endpoint='/api/education',fetchImpl=globalThis.fetch,isCurrent=()=>true}){
 if(!isCurrent()||!root||typeof accessToken!=='string'||!accessToken||endpoint!=='/api/education')throw Error('Education unavailable');
 const response=await fetchImpl(endpoint,{method:'POST',headers:{authorization:'Bearer '+accessToken,'content-type':'application/json'},body:JSON.stringify({organizationId}),cache:'no-store',redirect:'error',signal:AbortSignal.timeout(10000)});
 if(!response.ok)throw Error('Pristup edukativnim sadržajima nije potvrđen.');
 const content=await response.text();if(!isCurrent()||!content.includes('signatureEducationGuard')||!content.includes('signatureEducationIsolation'))throw Error('Unexpected education document');
 const frame=root.ownerDocument.createElement('iframe');frame.title='AUREA · Simulacije razgovora';frame.setAttribute('sandbox','allow-scripts');frame.referrerPolicy='no-referrer';frame.srcdoc=content;frame.style.width='100%';frame.style.minHeight='80vh';frame.style.border='0';root.replaceChildren(frame);
 return ()=>{frame.srcdoc='';frame.remove();};
}
module.exports={mountEducation};
